--
-- PostgreSQL database dump
--

\restrict n5ZJ5chBJf0mHfms44DyZFpvYefWQ2brFgtBx7nPLFrAhPC8DRn6kkW5nyN7eF2

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: pilot_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pilot_events (
    event_id uuid NOT NULL,
    pilot_id uuid NOT NULL,
    event_name character varying(40) NOT NULL,
    week_start date NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    recipe_id character varying(150) DEFAULT ''::character varying NOT NULL,
    CONSTRAINT pilot_events_name CHECK (((event_name)::text = ANY ((ARRAY['planner_opened'::character varying, 'meal_selected'::character varying, 'plan_completed'::character varying, 'grocery_list_opened'::character varying, 'next_week_plan_created'::character varying])::text[]))),
    CONSTRAINT pilot_events_recipe CHECK (((((event_name)::text = 'meal_selected'::text) AND ((recipe_id)::text ~ '^[a-zA-Z0-9:_-]{1,150}$'::text)) OR (((event_name)::text <> 'meal_selected'::text) AND ((recipe_id)::text = ''::text)))),
    CONSTRAINT pilot_events_week CHECK (((EXTRACT(isodow FROM week_start) = (1)::numeric) AND ((week_start >= '2000-01-01'::date) AND (week_start <= '2100-12-31'::date))))
);


--
-- Name: recipe_nutrition; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_nutrition (
    recipe_id character varying NOT NULL,
    input_hash character varying(64) NOT NULL,
    data jsonb NOT NULL,
    analyzed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT recipe_nutrition_data_check CHECK ((jsonb_typeof(data) = 'object'::text)),
    CONSTRAINT recipe_nutrition_input_hash_check CHECK (((input_hash)::text ~ '^[a-f0-9]{64}$'::text))
);


--
-- Name: recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    ingredients text[] NOT NULL,
    steps text[] NOT NULL,
    step_analysis jsonb,
    image text,
    source_url text,
    cook_time integer,
    prep_time integer,
    servings text,
    credit_kind text,
    credit_name character varying(120),
    tags text[],
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT recipes_credit_check CHECK ((((credit_kind IS NULL) AND (credit_name IS NULL)) OR ((credit_kind IS NOT NULL) AND (credit_kind = ANY (ARRAY['chef'::text, 'mine'::text])) AND ((credit_name IS NULL) OR (((length(btrim((credit_name)::text)) >= 1) AND (length(btrim((credit_name)::text)) <= 120)) AND ((credit_name)::text = btrim((credit_name)::text)))) AND ((credit_kind = 'mine'::text) OR (credit_name IS NOT NULL))))),
    CONSTRAINT recipes_prep_time_check CHECK (((prep_time IS NULL) OR ((prep_time >= 0) AND (prep_time <= 10080))))
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    password text NOT NULL
);


--
-- Data for Name: recipe_nutrition; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recipe_nutrition (recipe_id, input_hash, data, analyzed_at) FROM stdin;
tablewise:real:v1:chicken-curry	901ebe89559b7d1bd5e072e549e518c1d4325bb2f4ec91cfdeccae254cbc2948	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 92, "carbsG": 46, "fiberG": 12, "sugarG": 22, "proteinG": 141, "caloriesKcal": 1595}, "version": 1, "inputHash": "901ebe89559b7d1bd5e072e549e518c1d4325bb2f4ec91cfdeccae254cbc2948", "analyzedAt": "2026-11-11T16:22:53.554Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.555254+00
tablewise:real:v1:salmon-egg-fried-rice	684b59c85734be1addb502bf49c184478e6db3f8aca822916f3d4f18239da7cd	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 46, "carbsG": 96, "fiberG": 9, "sugarG": 12, "proteinG": 55, "caloriesKcal": 1030}, "version": 1, "inputHash": "684b59c85734be1addb502bf49c184478e6db3f8aca822916f3d4f18239da7cd", "analyzedAt": "2026-11-11T16:22:53.556Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.557117+00
tablewise:real:v1:lentil-leek-soup	55a19b7ee5f18a6d9201834b3992d6568206ac0a6e75f6d770c41554058ece0a	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 4, "carbsG": 180, "fiberG": 28, "sugarG": 42, "proteinG": 47, "caloriesKcal": 920}, "version": 1, "inputHash": "55a19b7ee5f18a6d9201834b3992d6568206ac0a6e75f6d770c41554058ece0a", "analyzedAt": "2026-11-11T16:22:53.557Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.557947+00
tablewise:real:v1:baked-salmon	e5e12debe57f4cdc5548ca579dcfcbe0a5a77aee893ba23d5f2ba92b6d699347	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 84, "carbsG": 0, "fiberG": 0, "sugarG": 0, "proteinG": 112, "caloriesKcal": 1285}, "version": 1, "inputHash": "e5e12debe57f4cdc5548ca579dcfcbe0a5a77aee893ba23d5f2ba92b6d699347", "analyzedAt": "2026-11-11T16:22:53.558Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.558737+00
tablewise:real:v1:coconut-chickpea-curry	294143e07d62f1cbe93bd009b746f7f031a81e1e66fb74f484615ba2075a6dcf	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 112, "carbsG": 158, "fiberG": 40, "sugarG": 42, "proteinG": 51, "caloriesKcal": 1810}, "version": 1, "inputHash": "294143e07d62f1cbe93bd009b746f7f031a81e1e66fb74f484615ba2075a6dcf", "analyzedAt": "2026-11-11T16:22:53.559Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.559413+00
tablewise:real:v1:sundried-tomato-pasta	aabac82432219d34153d2bd3d24344d69b07bc9d6aa3a01f7eb8498196e0e541	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 64, "carbsG": 199, "fiberG": 13, "sugarG": 31, "proteinG": 57, "caloriesKcal": 1595}, "version": 1, "inputHash": "aabac82432219d34153d2bd3d24344d69b07bc9d6aa3a01f7eb8498196e0e541", "analyzedAt": "2026-11-11T16:22:53.559Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.559881+00
tablewise:real:v1:black-bean-quesadillas	945af933faf0a66cbf940b4032af2b59b8e6476768b9e85b039863beaf793711	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 109, "carbsG": 296, "fiberG": 30, "sugarG": 18, "proteinG": 109, "caloriesKcal": 2580}, "version": 1, "inputHash": "945af933faf0a66cbf940b4032af2b59b8e6476768b9e85b039863beaf793711", "analyzedAt": "2026-11-11T16:22:53.560Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.560461+00
tablewise:real:v1:spanish-omelette	dcdc4cf866ef1ffbedfb0b0623c2db70fa430fc4ee60d31ea4dea0befb376f80	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 75, "carbsG": 114, "fiberG": 17, "sugarG": 19, "proteinG": 68, "caloriesKcal": 1400}, "version": 1, "inputHash": "dcdc4cf866ef1ffbedfb0b0623c2db70fa430fc4ee60d31ea4dea0befb376f80", "analyzedAt": "2026-11-11T16:22:53.560Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.561039+00
tablewise:real:v1:tuna-pasta-bake	769d93b85f4174791892cbaa685919226c4e53e8594f687e67e8551648fa2f77	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 106, "carbsG": 388, "fiberG": 23, "sugarG": 48, "proteinG": 183, "caloriesKcal": 3240}, "version": 1, "inputHash": "769d93b85f4174791892cbaa685919226c4e53e8594f687e67e8551648fa2f77", "analyzedAt": "2026-11-11T16:22:53.561Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.561623+00
tablewise:real:v1:garlic-butter-chicken	454d08a28bf5fd0a32913fd9a9c88fb1c92f86f7e4720da62f8378e9ced7f489	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 70, "carbsG": 10, "fiberG": 2, "sugarG": 2, "proteinG": 114, "caloriesKcal": 1135}, "version": 1, "inputHash": "454d08a28bf5fd0a32913fd9a9c88fb1c92f86f7e4720da62f8378e9ced7f489", "analyzedAt": "2026-11-11T16:22:53.562Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.562322+00
tablewise:real:v1:sichuan-beef-stir-fry	0e239f40e94417a3122ab2a6966cd014a2a57fff8fc72019be29181bcec78811	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 71, "carbsG": 135, "fiberG": 13, "sugarG": 22, "proteinG": 80, "caloriesKcal": 1520}, "version": 1, "inputHash": "0e239f40e94417a3122ab2a6966cd014a2a57fff8fc72019be29181bcec78811", "analyzedAt": "2026-11-11T16:22:53.562Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.563258+00
tablewise:real:v1:spaghetti-meatballs	ba07bf687a0f035f9d6f252ee1f26d2faa9fa8e65010da5ea55c694367754058	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 246, "carbsG": 443, "fiberG": 23, "sugarG": 38, "proteinG": 221, "caloriesKcal": 4860}, "version": 1, "inputHash": "ba07bf687a0f035f9d6f252ee1f26d2faa9fa8e65010da5ea55c694367754058", "analyzedAt": "2026-11-11T16:22:53.563Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.564006+00
\.


--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recipes (id, title, ingredients, steps, step_analysis, image, source_url, cook_time, prep_time, servings, credit_kind, credit_name, tags, created_at, updated_at) FROM stdin;
tablewise:real:v1:chicken-curry	Easy chicken curry	{"2 tbsp sunflower oil","1 onion, thinly sliced","2 garlic cloves, crushed","1 thumb-sized piece ginger, grated","6 boneless skinless chicken thighs","3 tbsp medium curry paste","400 g canned chopped tomatoes","100 g Greek yogurt","1 small bunch coriander, chopped","50 g ground almonds","Salt, to taste","Naan bread or cooked basmati rice, optional, to serve"}	{"In a large frying pan, soften the onion in the oil with a pinch of salt over medium heat for 8–10 minutes.","Stir in the garlic and ginger for 1 minute. Cut the chicken into approximately 3 cm pieces and fry in the pan for 5 minutes.","Add the curry paste, tomatoes and 250 ml water. Bring to a boil, then simmer uncovered for 25–30 minutes, until the sauce thickens and the chicken is cooked through.","Mix in the yogurt, coriander and ground almonds. Adjust seasoning and serve; naan or separately cooked rice is optional."}	\N	\N	https://www.bbcgoodfood.com/recipes/easy-chicken-curry	45	5	4	\N	\N	{Dinner,Chicken,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:real:v1:salmon-egg-fried-rice	Salmon egg-fried rice	{"1 thumb-sized piece ginger, grated","1–2 garlic cloves, grated","2 tbsp low-salt soy sauce","0.5 tbsp rice wine vinegar","2 tbsp vegetable oil","1 large carrot, chopped","175 g baby corn and mangetout, chopped","2 skinless smoked salmon fillets","250 g pouch cooked brown basmati rice","2 eggs","Hot sauce, optional, to serve"}	{"Combine the ginger, garlic, soy sauce and vinegar in a bowl.","Heat a large wok with 1 tablespoon oil. Add the carrot, mixed vegetables and salmon; cook the fish for approximately 2 minutes per side.","Stir in the ready-cooked rice, separating the fish into flakes. Push the mixture aside, add the remaining oil and scramble the eggs in the clear space.","Fold everything together with the soy mixture and heat thoroughly for a few minutes. Offer hot sauce separately."}	\N	\N	https://www.bbcgoodfood.com/recipes/salmon-egg-fried-rice	10	10	2–3	\N	\N	{Dinner,Fish,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:real:v1:lentil-leek-soup	Red lentil, carrot and leek soup	{"2 litres vegetable stock","150 g red lentils","6 carrots, finely chopped","2 medium leeks, sliced (about 300 g)","1 small handful parsley, chopped","Salt and black pepper, to taste"}	{"Heat the vegetable stock in a large saucepan and stir in the red lentils.","Bring to a boil and let the lentils start softening for a few minutes.","Add carrots and leeks, season to taste, cover and simmer gently for 45–60 minutes until the vegetables are tender and the lentils break down.","Top each portion with parsley. The source also allows ham stock; this version selects its vegetarian stock option."}	\N	\N	https://www.bbcgoodfood.com/recipes/lentil-soup	60	10	4	\N	\N	{Dinner,Vegetarian,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:real:v1:baked-salmon	Simple baked salmon	{"4 skinless salmon fillets","1 tbsp olive oil","Salt and black pepper, to taste","Chopped herbs, optional, to serve","Lemon slices, optional, to serve","Steamed long-stem broccoli, optional, to serve"}	{"Preheat the oven to 180°C, or 160°C fan. Brush the salmon with olive oil and season.","Arrange the fillets in an ovenproof dish. Cover for a softer finish, or leave uncovered for a lightly roasted surface.","Bake for 10–15 minutes, adjusting for thickness, until the fish is opaque and flakes readily.","Serve with the optional herbs, lemon and separately steamed broccoli. Those accompaniments are not a fixed quantity in the source."}	\N	\N	https://www.bbcgoodfood.com/recipes/baked-salmon	15	5	4	\N	\N	{Dinner,Fish,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:real:v1:coconut-chickpea-curry	Coconut chickpea and kale curry	{"1.5 tbsp curry powder","1 tsp cumin","1 yellow onion, diced","2 garlic cloves, minced","1 tsp fresh ginger, grated","2 tbsp olive oil","2 cans chickpeas (15 oz each), drained","1 can tomato sauce (8 oz)","1 can full-fat coconut milk (13.5 oz)","4 oz kale, chopped","Salt, to taste","Cooked rice or bread, optional, to serve"}	{"Dice the onion, mince the garlic, grate the ginger and chop the kale.","Toast the curry powder and cumin in a dry deep skillet over medium-low heat for approximately 1 minute.","Add the olive oil, onion, garlic and ginger; soften for approximately 5 minutes. Stir in drained chickpeas, tomato sauce and coconut milk.","Bring to a simmer, reduce the heat and cook for 15 minutes, stirring occasionally.","Fold in the kale and cook approximately 5 minutes more, until tender. Salt to taste and offer separately prepared rice or bread if desired."}	\N	\N	https://www.budgetbytes.com/coconut-curry-chickpeas/	25	10	4	\N	\N	{Dinner,Vegan,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:real:v1:sundried-tomato-pasta	One-pot creamy sun-dried tomato pasta	{"0.5 cup sun-dried tomatoes","2 tbsp butter","2 garlic cloves, minced","8 oz fettuccine","0.5 tsp dried basil","Black pepper, to taste","2 cups chicken broth","2 oz cream cheese","1 cup whole milk","0.25 cup grated Parmesan"}	{"Chop the sun-dried tomatoes. Melt the butter in a deep skillet and gently fry the garlic for approximately 1 minute.","Add pasta, tomatoes, basil, pepper and chicken broth. Break the pasta if necessary so it sits in the liquid.","Cover, bring to a boil, then reduce to a gentle simmer. Stir every few minutes and replace the lid.","Cook for 7–10 minutes until the pasta is tender and most broth is absorbed. Over low heat, melt in the cream cheese, then stir in milk and Parmesan to finish the sauce."}	\N	\N	https://www.budgetbytes.com/one-pot-creamy-sun-dried-tomato-pasta/	20	10	4	\N	\N	{Dinner,Pasta,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:real:v1:black-bean-quesadillas	Black bean and corn quesadillas	{"1 can black beans (15 oz), drained","1 cup frozen corn","0.5 cup red onion, diced","1 garlic clove, minced","0.25 bunch cilantro (about 0.5 cup chopped)","2 cups shredded cheddar cheese","1 packet taco seasoning","10 flour tortillas (7-inch)"}	{"Combine drained black beans and frozen corn in a bowl; the corn need not be thawed first.","Mix in the diced onion, garlic, cilantro, cheese and taco seasoning. The source permits a shop-bought packet instead of homemade seasoning.","Spread approximately half a cup of filling over one half of each tortilla, then fold closed.","Brown both sides in a skillet over medium heat until crisp and the filling is hot and melted. Cut into wedges.","The publisher's yield is 10 quesadillas, not a claim that the batch supplies 10 full dinner portions. Its 10-minute cooking time is the published value; multiple skillet batches may take longer."}	\N	\N	https://www.budgetbytes.com/hearty-black-bean-quesadillas/	10	5	10 quesadillas	\N	\N	{Dinner,Vegetarian,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:real:v1:spanish-omelette	Spanish potato and pepper omelette	{"500 g waxy potatoes","Butter, a knob plus a little extra for the pan","2 small onions, finely sliced","1 red pepper, chopped","8–9 eggs","25 g chives","Salt and black pepper, to taste"}	{"Slice the potatoes approximately 0.5 cm thick. Gently cook onions in butter in a roughly 24 cm frying pan for 10–15 minutes, then add pepper for 5 minutes.","Meanwhile, soften the potatoes in a saucepan of boiling water for 8–10 minutes, then drain.","Beat eggs in a jug, add seasoning and snipped chives. Heat the grill and add a little more butter and the potatoes to the frying pan.","Pour in the eggs and cook gently for approximately 15 minutes until almost set and browned beneath.","Finish under the grill for 1–2 minutes. Protect yourself from the hot handle; use a suitable pan. The metadata retains the publisher's stated 30-minute cooking time."}	\N	\N	https://www.bbcgoodfood.com/recipes/spanish-omelette	30	10	3–4	\N	\N	{Dinner,Vegetarian,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:real:v1:tuna-pasta-bake	Easy tuna and sweetcorn pasta bake	{"400 g fusilli pasta","100 g frozen peas","50 g butter","50 g plain flour","600 ml milk","1 tsp Dijon mustard","2 cans tuna (195 g each), drained","4 spring onions, sliced","198 g canned sweetcorn, drained","100 g cheddar cheese, grated","Salt and black pepper, to taste"}	{"Cook pasta in a saucepan according to its packet, adding peas for the last 3 minutes.","Meanwhile, melt butter in a second saucepan. Stir in flour and cook for 2 minutes, then gradually whisk in milk.","Bring the sauce gently to a boil while stirring until thick. Remove from heat, add mustard and season.","Heat the grill to medium. Drain pasta and peas, combine with tuna, spring onions, sweetcorn and sauce, and transfer to a shallow baking dish.","Scatter over cheddar and grill approximately 5 minutes until bubbling and golden."}	\N	\N	https://www.bbcgoodfood.com/recipes/easy-tuna-pasta-bake	20	10	4	\N	\N	{Dinner,Fish,Pasta,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:real:v1:garlic-butter-chicken	Garlic butter baked chicken thighs	{"4 tbsp butter","4 garlic cloves, minced","0.25 tsp paprika","0.25 tsp salt","Black pepper, to taste","1 lemon","2 tbsp chopped parsley, optional","5 boneless skinless chicken thighs (about 1.25 lb)"}	{"Heat the oven to 400°F (approximately 200°C). Melt the butter in a microwave-safe bowl for approximately 30 seconds.","Stir in garlic, paprika, salt, pepper and half the optional parsley.","Place the chicken in an 8 by 8 inch baking dish and coat with garlic butter. Add sliced lemon around the pieces.","Bake for 30–35 minutes, until the chicken reaches an internal temperature of 165°F (74°C).","Spoon the cooking juices over the chicken and finish with the remaining optional parsley."}	\N	\N	https://www.budgetbytes.com/garlic-butter-baked-chicken-thighs/	35	5	5	\N	\N	{Dinner,Chicken,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:real:v1:sichuan-beef-stir-fry	Beef and Sichuan pepper stir-fry	{"2 tbsp rapeseed oil","300 g steak, thinly sliced","1 tbsp cornflour","2 mixed peppers, sliced","200 g baby corn, halved","2 small red onions, sliced","0.5 tsp chilli flakes","1 tsp Sichuan peppercorns, ground","2 tbsp low-salt dark soy sauce","1 tbsp chilli oil, optional","300 g cooked brown basmati rice"}	{"Grind the Sichuan peppercorns using a pestle and mortar.","Heat 1 tablespoon rapeseed oil in a large wok. Add steak and cornflour, turn to coat, and fry for 2–3 minutes until browned; transfer to a plate.","Add remaining oil, peppers, baby corn and onion. Stir-fry for 3–4 minutes, then return beef and its juices with chilli flakes and Sichuan pepper.","Cook for 1 minute, add soy sauce and 50 ml water, and stir until the sauce coats everything. Serve with the ready-cooked rice and optional chilli oil."}	\N	\N	https://www.bbcgoodfood.com/recipes/beef-sichuan-pepper-stir-fry	10	10	4	\N	\N	{Dinner,Beef,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:real:v1:spaghetti-meatballs	Spaghetti with beef and sausage meatballs	{"8 sausages, skins removed","500 g minced beef","4 garlic cloves, crushed","1 small bunch parsley, chopped","3 tbsp dried breadcrumbs","1 egg, beaten","Plain flour, for rolling","4 tbsp sunflower oil","2 cans chopped tomatoes","1 pinch sugar","500 g spaghetti","Grated Parmesan, to serve","Salt and black pepper, to taste"}	{"Combine sausage meat, beef, half the garlic and parsley, breadcrumbs and egg in a large bowl. Season and mix.","On a floured chopping board, roll dessertspoon-sized portions into balls. Brown in batches in a large frying pan with 3 tablespoons oil, then set aside.","Discard excess fat and clean the pan. Warm the remaining oil, briefly fry remaining garlic, then cook the tomatoes for 5 minutes; season with sugar, salt and pepper.","Return meatballs, cover and simmer gently for approximately 30 minutes, turning in the sauce and adding a little water if needed.","Cook spaghetti in a saucepan during the final 15 minutes. Stir parsley into the sauce and serve over drained pasta with Parmesan."}	\N	\N	https://www.bbcgoodfood.com/recipes/meatballs-spaghetti	45	30	6	\N	\N	{Dinner,Beef,Pasta,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:002	Sardine linguine	{"250 g dry pasta","1 tin sardines or mackerel, drained (or 300 g cleaned mussels)","2 garlic cloves, minced","200 g cherry tomatoes","2 tbsp olive oil","1 tbsp lemon juice","Chopped parsley, to taste"}	{"Cook pasta in salted water and reserve a little cooking liquid.","Warm oil and garlic, then soften tomatoes in a pan.","Add fish and warm through, or cook mussels until opened; discard unopened mussels.","Toss with pasta, lemon juice and parsley; loosen with pasta water."}	\N	\N	https://www.jamieoliver.com/recipes/pasta/	15	10	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:004	Simple caponata	{"400 g main ingredient named in the title","1 onion, diced","2 garlic cloves, minced","2 tbsp olive oil","200 ml vegetable or chicken stock","1 tsp mixed spices","Salt and pepper, to taste"}	{"Prepare and cut the main ingredient into evenly sized pieces.","Heat oil and soften the onion and garlic.","Add the main ingredient, stock and spices.","Cook until tender and safely cooked through; adjust seasoning and serve."}	\N	\N	https://www.jamieoliver.com/recipes/pasta/	30	20	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:006	Simple arrabbiata	{"250 g dry pasta","2 tbsp olive oil","2 garlic cloves, minced","300 g tomatoes, chopped","1 small courgette or bell pepper, diced","1 tsp dried herbs","Salt and pepper, to taste"}	{"Cook pasta according to the package directions; drain.","Heat oil, sauté garlic and vegetables until softened.","Add tomatoes and herbs and simmer for 10 minutes.","Combine sauce with pasta; season and serve."}	\N	\N	https://www.jamieoliver.com/recipes/pasta/	20	10	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:016	Chicken Alfredo	{"250 g dry pasta","300 g boneless chicken or turkey, diced","2 garlic cloves, minced","200 g canned tomatoes","2 tbsp olive oil","1 tsp dried basil","Salt and pepper, to taste"}	{"Cook pasta according to package directions.","Sauté poultry in oil until fully cooked.","Add garlic, tomatoes and basil; simmer 8 minutes.","Toss with drained pasta, season and serve."}	\N	\N	https://www.jamieoliver.com/recipes/pasta/	25	15	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:017	Brilliant Bolognese	{"300 g ground beef","250 g dry pasta","1 onion, diced","2 garlic cloves, minced","400 g canned crushed tomatoes","1 tbsp olive oil","1 tsp dried oregano","Salt and pepper, to taste"}	{"Heat oil and cook onion for 3 minutes; add garlic.","Add beef and cook until browned and fully cooked.","Stir in tomatoes and oregano; simmer 15–20 minutes.","Cook pasta separately, drain and combine with sauce."}	\N	\N	https://www.jamieoliver.com/recipes/pasta/	30	15	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:021	Feta & tomato pasta	{"250 g dry pasta","2 tbsp olive oil","2 garlic cloves, minced","300 g tomatoes, chopped","1 small courgette or bell pepper, diced","1 tsp dried herbs","Salt and pepper, to taste"}	{"Cook pasta according to the package directions; drain.","Heat oil, sauté garlic and vegetables until softened.","Add tomatoes and herbs and simmer for 10 minutes.","Combine sauce with pasta; season and serve."}	\N	\N	https://www.jamieoliver.com/recipes/pasta/	25	10	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:026	Sticky orange chicken	{"600 g chicken thighs or breast","2 tbsp olive oil","2 garlic cloves, minced","1 tsp paprika","1 tsp ground cumin","1 tbsp lemon juice","Salt and pepper, to taste"}	{"Preheat oven to 200°C (392°F).","Mix oil, garlic, spices, lemon and seasoning.","Coat chicken and place on a baking tray.","Roast until chicken reaches 74°C (165°F) internally, about 25–35 minutes depending on cut."}	\N	\N	https://www.jamieoliver.com/recipes/chicken/	25	15	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:034	Chicken shawarma	{"600 g chicken thighs or breast","2 tbsp olive oil","2 garlic cloves, minced","1 tsp paprika","1 tsp ground cumin","1 tbsp lemon juice","Salt and pepper, to taste"}	{"Preheat oven to 200°C (392°F).","Mix oil, garlic, spices, lemon and seasoning.","Coat chicken and place on a baking tray.","Roast until chicken reaches 74°C (165°F) internally, about 25–35 minutes depending on cut."}	\N	\N	https://www.jamieoliver.com/recipes/chicken/	30	20	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:036	Gorgeous Greek salad	{"1 cucumber, chopped","2 tomatoes, chopped","1 small red onion, sliced","2 tbsp olive oil","1 tbsp fresh lemon juice","2 tbsp chopped parsley","Salt and black pepper, to taste"}	{"Wash and chop vegetables into bite-size pieces.","Whisk together oil, lemon juice, salt and pepper.","Combine vegetables and herbs in a bowl.","Toss with dressing just before serving."}	\N	\N	https://www.jamieoliver.com/recipes/dishtype/salad/	0	15	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:037	Healthy chicken Caesar	{"600 g chicken thighs or breast","2 tbsp olive oil","2 garlic cloves, minced","1 tsp paprika","1 tsp ground cumin","1 tbsp lemon juice","Salt and pepper, to taste"}	{"Preheat oven to 200°C (392°F).","Mix oil, garlic, spices, lemon and seasoning.","Coat chicken and place on a baking tray.","Roast until chicken reaches 74°C (165°F) internally, about 25–35 minutes depending on cut."}	\N	\N	https://www.jamieoliver.com/recipes/dishtype/salad/	15	20	2	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:039	Summer chickpea salad	{"1 cucumber, chopped","2 tomatoes, chopped","1 small red onion, sliced","2 tbsp olive oil","1 tbsp fresh lemon juice","2 tbsp chopped parsley","Salt and black pepper, to taste"}	{"Wash and chop vegetables into bite-size pieces.","Whisk together oil, lemon juice, salt and pepper.","Combine vegetables and herbs in a bowl.","Toss with dressing just before serving."}	\N	\N	https://www.jamieoliver.com/recipes/dishtype/salad/	0	15	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:041	Stuffed Pork Tenderloin	{"700 g beef or lamb (matching the recipe title)","1 large onion, sliced","2 carrots, cut into chunks","3 garlic cloves","2 tbsp olive oil","250 ml stock","1 tsp paprika","Salt and pepper, to taste"}	{"Heat oven to 160°C (320°F) for a slow braise.","Brown meat in oil, then transfer to a lidded baking dish.","Add vegetables, stock and seasonings; cover tightly.","Cook until the cut is tender, checking liquid occasionally; timing varies by cut."}	\N	\N	https://www.gordonramsay.com/gr/recipes/	45	25	6	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:042	Roast Beef with Caramelised Onion Gravy	{"700 g beef or lamb (matching the recipe title)","1 large onion, sliced","2 carrots, cut into chunks","3 garlic cloves","2 tbsp olive oil","250 ml stock","1 tsp paprika","Salt and pepper, to taste"}	{"Heat oven to 160°C (320°F) for a slow braise.","Brown meat in oil, then transfer to a lidded baking dish.","Add vegetables, stock and seasonings; cover tightly.","Cook until the cut is tender, checking liquid occasionally; timing varies by cut."}	\N	\N	https://www.gordonramsay.com/gr/recipes/	90	20	6	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:047	Vanilla-Infused Panna Cotta with Pomegranate Glaze	{"400 ml whipping cream","100 ml milk","50 g sugar","1 tsp vanilla extract","7 g powdered gelatin","3 tbsp cold water"}	{"Bloom gelatin in cold water according to package directions.","Warm cream, milk, sugar and vanilla without boiling.","Dissolve bloomed gelatin into warm mixture.","Pour into ramekins and refrigerate until set, about 4 hours."}	\N	\N	https://www.gordonramsay.com/gr/recipes/	10	15	6	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:048	Puerto Rican Style Steak Sandwich	{"350 g beef strips","2 sandwich rolls","1 onion, sliced","1 tbsp olive oil","1 tsp paprika","2 tbsp mustard or sauce","Salt and pepper, to taste"}	{"Season the beef with paprika, salt and pepper.","Sauté onion in oil until soft; remove from pan.","Cook beef to your preferred doneness with appropriate food-safety handling.","Fill rolls with beef, onions and sauce."}	\N	\N	https://www.gordonramsay.com/gr/recipes/	15	15	2	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:049	Smoky Mountain Cheesy Crawfish Omelette	{"450 g boneless fish fillets","1 tbsp olive oil","1 tbsp lemon juice","2 garlic cloves, minced","1 tsp paprika","2 tbsp chopped parsley","Salt and pepper, to taste"}	{"Pat fish dry and season with salt, pepper and paprika.","Heat oil in a nonstick frying pan over medium heat.","Cook fish until opaque and it flakes easily; use safe internal temperature guidance.","Finish with garlic, lemon and parsley; serve."}	\N	\N	https://www.gordonramsay.com/gr/recipes/	15	10	2	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:050	Michigan French Toast Sandwich	{"200 g all-purpose flour","80 g sugar","2 eggs","100 ml milk","80 ml neutral oil","1 tsp baking powder","1 tsp vanilla extract"}	{"Preheat oven to 180°C (356°F) and prepare a baking pan or muffin tin.","Whisk eggs, milk, oil, sugar and vanilla.","Fold in flour and baking powder until just combined.","Bake until golden and a skewer comes out clean; cool before serving."}	\N	\N	https://www.gordonramsay.com/gr/recipes/	10	10	2	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:053	מאפינס בננה עם שוקולד צ׳יפס	{"200 g all-purpose flour","80 g sugar","2 eggs","100 ml milk","80 ml neutral oil","1 tsp baking powder","1 tsp vanilla extract"}	{"Preheat oven to 180°C (356°F) and prepare a baking pan or muffin tin.","Whisk eggs, milk, oil, sugar and vanilla.","Fold in flour and baking powder until just combined.","Bake until golden and a skewer comes out clean; cool before serving."}	\N	\N	https://www.goodlifetv.co.il/talents/המתכונים-של-אביב-משה-עכשיו-בערוץ-האוכל/	25	15	12 muffins	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:084	Courgette chickpea & pasta salad	{"250 g dry pasta","1 cucumber, diced","150 g cherry tomatoes, halved","2 tbsp olive oil","1 tbsp lemon juice","Handful fresh herbs","Salt and pepper, to taste"}	{"Cook pasta in salted water until tender and drain.","Rinse briefly in cool water and let drain fully.","Chop cucumber, tomatoes and herbs.","Toss with oil, lemon juice, seasoning and pasta."}	\N	\N	https://www.jamieoliver.com/recipes/dishtype/salad/	12	15	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
tablewise:synthetic:v1:100	Warm lentil salad	{"1 cucumber, chopped","2 tomatoes, chopped","1 small red onion, sliced","2 tbsp olive oil","1 tbsp fresh lemon juice","2 tbsp chopped parsley","Salt and black pepper, to taste"}	{"Wash and chop vegetables into bite-size pieces.","Whisk together oil, lemon juice, salt and pepper.","Combine vegetables and herbs in a bowl.","Toss with dressing just before serving."}	\N	\N	https://www.jamieoliver.com/recipes/dishtype/salad/	25	10	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074
\.


--
-- Name: pilot_events pilot_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pilot_events
    ADD CONSTRAINT pilot_events_pkey PRIMARY KEY (event_id);


--
-- Name: pilot_events pilot_events_semantic; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pilot_events
    ADD CONSTRAINT pilot_events_semantic UNIQUE (pilot_id, event_name, week_start, recipe_id);


--
-- Name: recipe_nutrition recipe_nutrition_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_nutrition
    ADD CONSTRAINT recipe_nutrition_pkey PRIMARY KEY (recipe_id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: pilot_events_completion; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pilot_events_completion ON public.pilot_events USING btree (pilot_id, occurred_at, event_id) WHERE ((event_name)::text = 'plan_completed'::text);


--
-- Name: pilot_events_funnel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pilot_events_funnel ON public.pilot_events USING btree (event_name, week_start);


--
-- Name: recipe_nutrition recipe_nutrition_recipe_id_recipes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_nutrition
    ADD CONSTRAINT recipe_nutrition_recipe_id_recipes_id_fk FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict n5ZJ5chBJf0mHfms44DyZFpvYefWQ2brFgtBx7nPLFrAhPC8DRn6kkW5nyN7eF2

