--
-- PostgreSQL database dump
--

\restrict pV2boW4eAoCrTnmyKtkND0IYBhIhCSnPWrMrLvEUsmgrGPnsjvTLtGsj6OX6zYs

-- Dumped from database version 16.16 (Debian 16.16-1.pgdg13+1)
-- Dumped by pg_dump version 16.16 (Debian 16.16-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_sessions (
    token_hash character varying(64) NOT NULL,
    account_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(254) NOT NULL,
    password_hash text,
    owner_id character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    display_name character varying(60),
    photo text,
    photo_version integer DEFAULT 0 NOT NULL,
    CONSTRAINT accounts_photo CHECK (((photo IS NULL) OR (length(photo) <= 280023)))
);


--
-- Name: cooking_photos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cooking_photos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    owner_id character varying(64) NOT NULL,
    image bytea NOT NULL,
    thumbnail bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: cooking_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cooking_sessions (
    id uuid NOT NULL,
    owner_id character varying(64) NOT NULL,
    recipe_id character varying NOT NULL,
    cooked_at timestamp with time zone DEFAULT now() NOT NULL,
    rating smallint,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cooking_sessions_notes CHECK (((notes IS NULL) OR (length(notes) <= 4000))),
    CONSTRAINT cooking_sessions_rating CHECK (((rating IS NULL) OR ((rating >= 1) AND (rating <= 5))))
);


--
-- Name: grocery_extras; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grocery_extras (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying(64) NOT NULL,
    text text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    image text,
    category text,
    CONSTRAINT grocery_extras_image CHECK (((image IS NULL) OR (length(image) <= 280023))),
    CONSTRAINT grocery_extras_text CHECK (((length(text) >= 1) AND (length(text) <= 80)))
);


--
-- Name: grocery_item_photos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grocery_item_photos (
    owner_id character varying(64) NOT NULL,
    item_key text NOT NULL,
    image text,
    CONSTRAINT grocery_item_photos_image CHECK (((image IS NULL) OR (length(image) <= 280023))),
    CONSTRAINT grocery_item_photos_key CHECK (((length(item_key) >= 1) AND (length(item_key) <= 12000)))
);


--
-- Name: grocery_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grocery_notes (
    owner_id character varying(64) NOT NULL,
    item_key character varying(300) NOT NULL,
    note character varying(500) NOT NULL
);


--
-- Name: grocery_shopping_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grocery_shopping_items (
    owner_id character varying(64) NOT NULL,
    item_key text NOT NULL,
    skipped boolean DEFAULT false NOT NULL,
    price_cents integer,
    price_text text,
    quantity text,
    CONSTRAINT grocery_shopping_items_price_check CHECK ((((price_cents IS NULL) AND (price_text IS NULL)) OR ((price_cents IS NOT NULL) AND ((price_cents >= 0) AND (price_cents <= 10000000)) AND (price_text IS NOT NULL)))),
    CONSTRAINT grocery_shopping_items_quantity_check CHECK (((quantity IS NULL) OR ((length(quantity) >= 1) AND (length(quantity) <= 40))))
);


--
-- Name: home_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.home_tasks (
    id uuid NOT NULL,
    owner_id character varying(64) NOT NULL,
    name text NOT NULL,
    due_date date,
    priority character varying(8) NOT NULL,
    image text,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT home_tasks_image CHECK (((image IS NULL) OR (length(image) <= 280023))),
    CONSTRAINT home_tasks_name CHECK (((length(name) >= 1) AND (length(name) <= 120))),
    CONSTRAINT home_tasks_priority CHECK (((priority)::text = ANY ((ARRAY['high'::character varying, 'normal'::character varying, 'low'::character varying])::text[])))
);


--
-- Name: household_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.household_products (
    id text NOT NULL,
    category text NOT NULL,
    names jsonb NOT NULL,
    aliases jsonb NOT NULL
);


--
-- Name: household_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.household_settings (
    owner_id character varying(64) NOT NULL,
    settings jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: household_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.household_tasks (
    id text NOT NULL,
    names jsonb NOT NULL
);


--
-- Name: pilot_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pilot_events (
    event_id uuid NOT NULL,
    pilot_id uuid NOT NULL,
    event_name character varying(40) NOT NULL,
    week_start date NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    recipe_id character varying(150) DEFAULT ''::character varying NOT NULL,
    CONSTRAINT pilot_events_name CHECK (((event_name)::text = ANY ((ARRAY['planner_opened'::character varying, 'meal_selected'::character varying, 'plan_completed'::character varying, 'grocery_list_opened'::character varying, 'next_week_plan_created'::character varying])::text[]))),
    CONSTRAINT pilot_events_recipe CHECK (((((event_name)::text = 'meal_selected'::text) AND ((recipe_id)::text ~ '^[a-zA-Z0-9:_-]{1,150}$'::text)) OR (((event_name)::text <> 'meal_selected'::text) AND ((recipe_id)::text = ''::text)))),
    CONSTRAINT pilot_events_week CHECK (((EXTRACT(isodow FROM week_start) = (1)::numeric) AND ((week_start >= '2000-01-01'::date) AND (week_start <= '2100-12-31'::date))))
);


--
-- Name: recipe_generations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_generations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying(64) NOT NULL,
    search_text character varying(120) NOT NULL,
    request jsonb NOT NULL,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    draft jsonb NOT NULL,
    model character varying(80) NOT NULL,
    prompt_version character varying(80) NOT NULL,
    attempts integer DEFAULT 1 NOT NULL,
    recipe_id character varying,
    approved_by character varying(64),
    approved_at timestamp with time zone,
    published_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT recipe_generations_published CHECK ((((status)::text <> 'published'::text) OR ((approved_at IS NOT NULL) AND (published_at IS NOT NULL)))),
    CONSTRAINT recipe_generations_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'pending_review'::character varying, 'changes_requested'::character varying, 'rejected'::character varying, 'published'::character varying, 'unpublished'::character varying])::text[])))
);


--
-- Name: recipe_marks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_marks (
    owner_id character varying(64) NOT NULL,
    recipe_id character varying NOT NULL,
    kind character varying(8) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT recipe_marks_kind CHECK (((kind)::text = ANY ((ARRAY['liked'::character varying, 'imported'::character varying])::text[])))
);


--
-- Name: recipe_nutrition; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_nutrition (
    recipe_id character varying NOT NULL,
    input_hash character varying(64) NOT NULL,
    data jsonb NOT NULL,
    analyzed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT recipe_nutrition_data_check CHECK ((jsonb_typeof(data) = 'object'::text)),
    CONSTRAINT recipe_nutrition_input_hash_check CHECK (((input_hash)::text ~ '^[a-f0-9]{64}$'::text))
);


--
-- Name: recipe_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_sources (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    recipe_id character varying NOT NULL,
    owner_id character varying(64) NOT NULL,
    provider character varying(16) NOT NULL,
    original_url text NOT NULL,
    canonical_url text NOT NULL,
    external_video_id character varying(32) NOT NULL,
    status character varying(8) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT recipe_sources_provider CHECK (((provider)::text = 'youtube'::text)),
    CONSTRAINT recipe_sources_status CHECK (((status)::text = ANY ((ARRAY['mock'::character varying, 'pending'::character varying, 'ready'::character varying, 'failed'::character varying])::text[])))
);


--
-- Name: recipe_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_translations (
    recipe_id character varying NOT NULL,
    language character varying(2) NOT NULL,
    title text NOT NULL,
    ingredients text[] NOT NULL,
    steps text[] NOT NULL,
    translated_by character varying(8) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT recipe_translations_language CHECK (((language)::text = ANY ((ARRAY['en'::character varying, 'ru'::character varying, 'he'::character varying])::text[]))),
    CONSTRAINT recipe_translations_translated_by CHECK (((translated_by)::text = ANY ((ARRAY['ai'::character varying, 'person'::character varying])::text[])))
);


--
-- Name: recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    ingredients text[] NOT NULL,
    steps text[] NOT NULL,
    step_analysis jsonb,
    image text,
    source_url text,
    cook_time integer,
    prep_time integer,
    servings text,
    credit_kind text,
    credit_name character varying(120),
    tags text[],
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    ingredient_parts jsonb,
    step_ingredients jsonb,
    language character varying(2),
    CONSTRAINT recipes_credit_check CHECK ((((credit_kind IS NULL) AND (credit_name IS NULL)) OR ((credit_kind IS NOT NULL) AND (credit_kind = ANY (ARRAY['chef'::text, 'mine'::text])) AND ((credit_name IS NULL) OR (((length(btrim((credit_name)::text)) >= 1) AND (length(btrim((credit_name)::text)) <= 120)) AND ((credit_name)::text = btrim((credit_name)::text)))) AND ((credit_kind = 'mine'::text) OR (credit_name IS NOT NULL))))),
    CONSTRAINT recipes_ingredient_parts_check CHECK (((ingredient_parts IS NULL) OR (jsonb_typeof(ingredient_parts) = 'array'::text))),
    CONSTRAINT recipes_language_check CHECK (((language IS NULL) OR ((language)::text ~ '^[a-z]{2}$'::text))),
    CONSTRAINT recipes_prep_time_check CHECK (((prep_time IS NULL) OR ((prep_time >= 0) AND (prep_time <= 10080)))),
    CONSTRAINT recipes_step_ingredients_check CHECK (((step_ingredients IS NULL) OR (jsonb_typeof(step_ingredients) = 'array'::text)))
);


--
-- Name: shared_grocery_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shared_grocery_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    list_id uuid NOT NULL,
    category character varying(40) NOT NULL,
    text character varying(300) NOT NULL,
    recipes character varying(300) DEFAULT ''::character varying NOT NULL,
    checked boolean DEFAULT false NOT NULL,
    note character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shared_grocery_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shared_grocery_lists (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying(64) NOT NULL,
    token character varying(64) NOT NULL,
    role character varying(8) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT shared_grocery_lists_role CHECK (((role)::text = ANY ((ARRAY['view'::character varying, 'add'::character varying, 'edit'::character varying])::text[])))
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    password text NOT NULL
);


--
-- Name: week_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.week_plans (
    owner_id character varying(64) NOT NULL,
    selected_ids jsonb NOT NULL,
    plan_assignments jsonb NOT NULL,
    locked boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    week_start date NOT NULL,
    proposed boolean DEFAULT false NOT NULL,
    approved_batches jsonb
);


--
-- Data for Name: household_products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.household_products (id, category, names, aliases) FROM stdin;
potatoes	Produce	{"en": "Potatoes", "he": "תפוחי אדמה", "ru": "Картофель"}	["potato"]
onions	Produce	{"en": "Onions", "he": "בצל", "ru": "Лук"}	["onion"]
carrots	Produce	{"en": "Carrots", "he": "גזר", "ru": "Морковь"}	["carrot"]
tomatoes	Produce	{"en": "Tomatoes", "he": "עגבניות", "ru": "Помидоры"}	["tomato"]
cucumbers	Produce	{"en": "Cucumbers", "he": "מלפפונים", "ru": "Огурцы"}	["cucumber"]
garlic	Produce	{"en": "Garlic", "he": "שום", "ru": "Чеснок"}	[]
lettuce	Produce	{"en": "Lettuce", "he": "חסה", "ru": "Салат"}	[]
spinach	Produce	{"en": "Spinach", "he": "תרד", "ru": "Шпинат"}	[]
broccoli	Produce	{"en": "Broccoli", "he": "ברוקולי", "ru": "Брокколи"}	[]
cauliflower	Produce	{"en": "Cauliflower", "he": "כרובית", "ru": "Цветная капуста"}	[]
cabbage	Produce	{"en": "Cabbage", "he": "כרוב", "ru": "Капуста"}	[]
bell-peppers	Produce	{"en": "Bell peppers", "he": "פלפלים", "ru": "Сладкий перец"}	["pepper"]
zucchini	Produce	{"en": "Zucchini", "he": "קישואים", "ru": "Кабачки"}	[]
mushrooms	Produce	{"en": "Mushrooms", "he": "פטריות", "ru": "Грибы"}	[]
apples	Produce	{"en": "Apples", "he": "תפוחים", "ru": "Яблоки"}	["apple"]
bananas	Produce	{"en": "Bananas", "he": "בננות", "ru": "Бананы"}	["banana"]
oranges	Produce	{"en": "Oranges", "he": "תפוזים", "ru": "Апельсины"}	["orange"]
lemons	Produce	{"en": "Lemons", "he": "לימונים", "ru": "Лимоны"}	["lemon"]
avocados	Produce	{"en": "Avocados", "he": "אבוקדו", "ru": "Авокадо"}	[]
strawberries	Produce	{"en": "Strawberries", "he": "תותים", "ru": "Клубника"}	[]
blueberries	Produce	{"en": "Blueberries", "he": "אוכמניות", "ru": "Черника"}	[]
grapes	Produce	{"en": "Grapes", "he": "ענבים", "ru": "Виноград"}	[]
milk	Dairy & Eggs	{"en": "Milk", "he": "חלב", "ru": "Молоко"}	[]
eggs	Dairy & Eggs	{"en": "Eggs", "he": "ביצים", "ru": "Яйца"}	["egg"]
butter	Dairy & Eggs	{"en": "Butter", "he": "חמאה", "ru": "Сливочное масло"}	[]
cheese	Dairy & Eggs	{"en": "Cheese", "he": "גבינה", "ru": "Сыр"}	[]
yogurt	Dairy & Eggs	{"en": "Yogurt", "he": "יוגורט", "ru": "Йогурт"}	["yoghurt"]
sour-cream	Dairy & Eggs	{"en": "Sour cream", "he": "שמנת חמוצה", "ru": "Сметана"}	[]
cream	Dairy & Eggs	{"en": "Cream", "he": "שמנת", "ru": "Сливки"}	[]
cottage-cheese	Dairy & Eggs	{"en": "Cottage cheese", "he": "קוטג׳", "ru": "Творог"}	[]
chicken	Meat & Poultry	{"en": "Chicken", "he": "עוף", "ru": "Курица"}	[]
ground-beef	Meat & Poultry	{"en": "Ground beef", "he": "בשר בקר טחון", "ru": "Говяжий фарш"}	["minced beef"]
turkey	Meat & Poultry	{"en": "Turkey", "he": "הודו", "ru": "Индейка"}	[]
beef	Meat & Poultry	{"en": "Beef", "he": "בקר", "ru": "Говядина"}	[]
salmon	Seafood	{"en": "Salmon", "he": "סלמון", "ru": "Лосось"}	[]
white-fish	Seafood	{"en": "White fish", "he": "דג לבן", "ru": "Белая рыба"}	[]
canned-tuna	Canned & Jarred	{"en": "Canned tuna", "he": "טונה בשימורים", "ru": "Тунец консервированный"}	[]
chickpeas	Canned & Jarred	{"en": "Chickpeas", "he": "חומוס", "ru": "Нут"}	[]
beans	Canned & Jarred	{"en": "Beans", "he": "שעועית", "ru": "Фасоль"}	[]
lentils	Canned & Jarred	{"en": "Lentils", "he": "עדשים", "ru": "Чечевица"}	[]
canned-tomatoes	Canned & Jarred	{"en": "Canned tomatoes", "he": "עגבניות משומרות", "ru": "Томаты консервированные"}	[]
tomato-paste	Canned & Jarred	{"en": "Tomato paste", "he": "רסק עגבניות", "ru": "Томатная паста"}	[]
corn	Canned & Jarred	{"en": "Corn", "he": "תירס", "ru": "Кукуруза"}	[]
peanut-butter	Canned & Jarred	{"en": "Peanut butter", "he": "חמאת בוטנים", "ru": "Арахисовая паста"}	[]
jam	Canned & Jarred	{"en": "Jam", "he": "ריבה", "ru": "Варенье"}	[]
honey	Canned & Jarred	{"en": "Honey", "he": "דבש", "ru": "Мёд"}	[]
bread	Grains & Pasta	{"en": "Bread", "he": "לחם", "ru": "Хлеб"}	[]
rice	Grains & Pasta	{"en": "Rice", "he": "אורז", "ru": "Рис"}	[]
pasta	Grains & Pasta	{"en": "Pasta", "he": "פסטה", "ru": "Макароны"}	[]
oats	Grains & Pasta	{"en": "Oats", "he": "שיבולת שועל", "ru": "Овсянка"}	["oatmeal"]
flour	Grains & Pasta	{"en": "Flour", "he": "קמח", "ru": "Мука"}	[]
gluten-free-flour	Grains & Pasta	{"en": "Gluten-free flour", "he": "קמח ללא גלוטן", "ru": "Безглютеновая мука"}	[]
gluten-free-bread	Grains & Pasta	{"en": "Gluten-free bread", "he": "לחם ללא גלוטן", "ru": "Безглютеновый хлеб"}	[]
gluten-free-pasta	Grains & Pasta	{"en": "Gluten-free pasta", "he": "פסטה ללא גלוטן", "ru": "Безглютеновые макароны"}	[]
cereal	Grains & Pasta	{"en": "Cereal", "he": "דגני בוקר", "ru": "Хлопья"}	[]
tortillas	Grains & Pasta	{"en": "Tortillas", "he": "טורטיות", "ru": "Тортильи"}	[]
salt	Spices & Seasonings	{"en": "Salt", "he": "מלח", "ru": "Соль"}	[]
black-pepper	Spices & Seasonings	{"en": "Black pepper", "he": "פלפל שחור", "ru": "Чёрный перец"}	[]
paprika	Spices & Seasonings	{"en": "Paprika", "he": "פפריקה", "ru": "Паприка"}	[]
cumin	Spices & Seasonings	{"en": "Cumin", "he": "כמון", "ru": "Кумин"}	[]
cinnamon	Spices & Seasonings	{"en": "Cinnamon", "he": "קינמון", "ru": "Корица"}	[]
olive-oil	Spices & Seasonings	{"en": "Olive oil", "he": "שמן זית", "ru": "Оливковое масло"}	[]
vegetable-oil	Spices & Seasonings	{"en": "Vegetable oil", "he": "שמן צמחי", "ru": "Растительное масло"}	[]
vinegar	Spices & Seasonings	{"en": "Vinegar", "he": "חומץ", "ru": "Уксус"}	[]
sugar	Other	{"en": "Sugar", "he": "סוכר", "ru": "Сахар"}	[]
baking-powder	Other	{"en": "Baking powder", "he": "אבקת אפייה", "ru": "Разрыхлитель"}	[]
baking-soda	Other	{"en": "Baking soda", "he": "סודה לשתייה", "ru": "Пищевая сода"}	[]
coffee	Other	{"en": "Coffee", "he": "קפה", "ru": "Кофе"}	[]
tea	Other	{"en": "Tea", "he": "תה", "ru": "Чай"}	[]
juice	Other	{"en": "Juice", "he": "מיץ", "ru": "Сок"}	[]
water	Other	{"en": "Water", "he": "מים", "ru": "Вода"}	[]
oat-milk	Other	{"en": "Oat milk", "he": "חלב שיבולת שועל", "ru": "Овсяное молоко"}	[]
almond-milk	Other	{"en": "Almond milk", "he": "חלב שקדים", "ru": "Миндальное молоко"}	[]
frozen-peas	Other	{"en": "Frozen peas", "he": "אפונה קפואה", "ru": "Замороженный горошек"}	[]
frozen-vegetables	Other	{"en": "Frozen vegetables", "he": "ירקות קפואים", "ru": "Замороженные овощи"}	[]
nuts	Other	{"en": "Nuts", "he": "אגוזים", "ru": "Орехи"}	[]
crackers	Other	{"en": "Crackers", "he": "קרקרים", "ru": "Крекеры"}	[]
toothbrush	Other	{"en": "Toothbrush", "he": "מברשת שיניים", "ru": "Зубная щётка"}	["tooth brush"]
toothpaste	Other	{"en": "Toothpaste", "he": "משחת שיניים", "ru": "Зубная паста"}	[]
dental-floss	Other	{"en": "Dental floss", "he": "חוט דנטלי", "ru": "Зубная нить"}	[]
soap	Other	{"en": "Soap", "he": "סבון", "ru": "Мыло"}	[]
shampoo	Other	{"en": "Shampoo", "he": "שמפו", "ru": "Шампунь"}	[]
conditioner	Other	{"en": "Conditioner", "he": "מרכך שיער", "ru": "Кондиционер для волос"}	[]
body-wash	Other	{"en": "Body wash", "he": "סבון רחצה", "ru": "Гель для душа"}	[]
deodorant	Other	{"en": "Deodorant", "he": "דאודורנט", "ru": "Дезодорант"}	[]
toilet-paper	Other	{"en": "Toilet paper", "he": "נייר טואלט", "ru": "Туалетная бумага"}	[]
tissues	Other	{"en": "Tissues", "he": "ממחטות נייר", "ru": "Бумажные платки"}	[]
paper-towels	Other	{"en": "Paper towels", "he": "מגבות נייר", "ru": "Бумажные полотенца"}	[]
dish-soap	Other	{"en": "Dish soap", "he": "סבון כלים", "ru": "Средство для мытья посуды"}	["washing up liquid"]
dishwasher-tablets	Other	{"en": "Dishwasher tablets", "he": "טבליות למדיח", "ru": "Таблетки для посудомоечной машины"}	[]
laundry-detergent	Other	{"en": "Laundry detergent", "he": "חומר כביסה", "ru": "Средство для стирки"}	[]
fabric-softener	Other	{"en": "Fabric softener", "he": "מרכך כביסה", "ru": "Кондиционер для белья"}	[]
all-purpose-cleaner	Other	{"en": "All-purpose cleaner", "he": "חומר ניקוי כללי", "ru": "Универсальное чистящее средство"}	[]
sponges	Other	{"en": "Sponges", "he": "ספוגים", "ru": "Губки"}	[]
garbage-bags	Other	{"en": "Garbage bags", "he": "שקיות אשפה", "ru": "Мусорные пакеты"}	["trash bags", "bin bags"]
aluminum-foil	Other	{"en": "Aluminum foil", "he": "נייר אלומיניום", "ru": "Фольга"}	["aluminium foil", "tin foil"]
baking-paper	Other	{"en": "Baking paper", "he": "נייר אפייה", "ru": "Бумага для выпечки"}	["parchment paper"]
food-storage-bags	Other	{"en": "Food storage bags", "he": "שקיות מזון", "ru": "Пакеты для хранения продуктов"}	[]
diapers	Other	{"en": "Diapers", "he": "חיתולים", "ru": "Подгузники"}	["nappies"]
baby-wipes	Other	{"en": "Baby wipes", "he": "מגבונים לתינוקות", "ru": "Детские влажные салфетки"}	[]
batteries	Other	{"en": "Batteries", "he": "סוללות", "ru": "Батарейки"}	[]
\.


--
-- Data for Name: household_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.household_tasks (id, names) FROM stdin;
do-laundry	{"en": "Do laundry", "he": "לעשות כביסה", "ru": "Постирать бельё"}
fold-laundry	{"en": "Fold laundry", "he": "לקפל כביסה", "ru": "Сложить бельё"}
iron-clothes	{"en": "Iron clothes", "he": "לגהץ בגדים", "ru": "Погладить одежду"}
change-bed-sheets	{"en": "Change bed sheets", "he": "להחליף מצעים", "ru": "Поменять постельное бельё"}
wash-dishes	{"en": "Wash the dishes", "he": "לשטוף כלים", "ru": "Помыть посуду"}
run-dishwasher	{"en": "Run the dishwasher", "he": "להפעיל מדיח", "ru": "Запустить посудомойку"}
empty-dishwasher	{"en": "Empty the dishwasher", "he": "לרוקן מדיח", "ru": "Разгрузить посудомойку"}
take-out-trash	{"en": "Take out the trash", "he": "להוציא את הזבל", "ru": "Вынести мусор"}
take-out-recycling	{"en": "Take out the recycling", "he": "להוציא מחזור", "ru": "Вынести вторсырьё"}
vacuum	{"en": "Vacuum", "he": "לשאוב אבק", "ru": "Пропылесосить"}
mop-floors	{"en": "Mop the floors", "he": "לשטוף רצפה", "ru": "Помыть полы"}
dust	{"en": "Dust the furniture", "he": "לנגב אבק", "ru": "Вытереть пыль"}
clean-bathroom	{"en": "Clean the bathroom", "he": "לנקות את חדר האמבטיה", "ru": "Убрать ванную"}
clean-toilet	{"en": "Clean the toilet", "he": "לנקות את האסלה", "ru": "Почистить унитаз"}
clean-kitchen	{"en": "Clean the kitchen", "he": "לנקות את המטבח", "ru": "Убрать кухню"}
clean-fridge	{"en": "Clean the fridge", "he": "לנקות את המקרר", "ru": "Помыть холодильник"}
clean-oven	{"en": "Clean the oven", "he": "לנקות את התנור", "ru": "Почистить духовку"}
clean-windows	{"en": "Clean the windows", "he": "לנקות חלונות", "ru": "Помыть окна"}
water-plants	{"en": "Water the plants", "he": "להשקות את העציצים", "ru": "Полить цветы"}
feed-pets	{"en": "Feed the pets", "he": "להאכיל את חיות המחמד", "ru": "Покормить питомцев"}
walk-dog	{"en": "Walk the dog", "he": "להוציא את הכלב", "ru": "Выгулять собаку"}
clean-litter-box	{"en": "Clean the litter box", "he": "לנקות ארגז חול", "ru": "Убрать кошачий лоток"}
pay-electricity-bill	{"en": "Pay electricity bill", "he": "לשלם חשבון חשמל", "ru": "Оплатить счёт за электричество"}
pay-water-bill	{"en": "Pay water bill", "he": "לשלם חשבון מים", "ru": "Оплатить счёт за воду"}
pay-rent	{"en": "Pay rent", "he": "לשלם שכר דירה", "ru": "Оплатить аренду"}
change-light-bulb	{"en": "Change a light bulb", "he": "להחליף נורה", "ru": "Заменить лампочку"}
replace-water-filter	{"en": "Replace the water filter", "he": "להחליף פילטר מים", "ru": "Заменить фильтр для воды"}
tidy-living-room	{"en": "Tidy the living room", "he": "לסדר את הסלון", "ru": "Прибраться в гостиной"}
make-beds	{"en": "Make the beds", "he": "לסדר את המיטות", "ru": "Заправить кровати"}
sort-mail	{"en": "Sort the mail", "he": "למיין את הדואר", "ru": "Разобрать почту"}
declutter-closet	{"en": "Declutter the closet", "he": "לסדר את הארון", "ru": "Разобрать шкаф"}
wash-car	{"en": "Wash the car", "he": "לשטוף את הרכב", "ru": "Помыть машину"}
\.


--
-- Data for Name: recipe_generations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recipe_generations (id, owner_id, search_text, request, status, draft, model, prompt_version, attempts, recipe_id, approved_by, approved_at, published_at, created_at, updated_at) FROM stdin;
2d9bbe4c-39b1-4658-bb3c-b9e686056845	608f70bd7d21148b0c8a9600c3c7b236e5fb1297525a760f5cfeb274bb166c0a	Pumpkin Pie	{"source": "recipe_search", "filters": {"dietary": ["Gluten-free"], "mealType": [], "servings": "5+", "maxMinutes": 30, "mustExclude": [], "mustInclude": [], "proteinType": [], "cookingMethod": []}, "timeMode": "preparation", "recipeName": "Pumpkin Pie", "schemaVersion": 1}	draft	{"tip": "Chill the bars completely before slicing for clean edges.", "recipe": {"tags": ["ai-generated", "meal:dinner", "meal:lunch", "glutenFree"], "steps": ["Preheat oven to 190°C.", "Line a 9x9 inch baking pan with parchment.", "In a bowl, mix almond flour, granulated sugar, and salt. Stir in melted butter until the mixture forms a sandy dough.", "Press the crust into the bottom of the prepared pan in an even layer. Bake 8 minutes and set aside to cool slightly.", "In another bowl, whisk pumpkin puree, eggs, coconut milk, brown sugar, cinnamon, nutmeg, ginger, cloves, and vanilla until smooth.", "Pour the filling over the warm crust; gently tap the pan to remove air bubbles.", "Bake 12 minutes, then rotate and bake 4 more minutes until set and a knife inserted in center comes out clean.", "Cool completely at room temperature, then refrigerate at least 1 hour before slicing into bars and serving."], "title": "Gluten-Free Pumpkin Pie Bars (Prep in 30 Minutes)", "cookTime": 10, "prepTime": 20, "servings": "5+", "ingredients": ["1 cup almond flour", "2 tbsp granulated sugar", "1/4 tsp salt", "2 tbsp melted butter or dairy-free butter substitute", "3/4 cup pumpkin puree (canned or home-made)", "2 eggs", "1/2 cup coconut milk or regular milk", "1/3 cup brown sugar", "1 tsp ground cinnamon", "1/4 tsp ground nutmeg", "1/4 tsp ground ginger", "1/8 tsp ground cloves", "1 pinch vanilla extract"]}, "description": "A gluten-free, no-shuffle pumpkin pie in bar form: silky pumpkin filling baked on a simple almond-crust, cut into bars for easy serving. Suitable for a crowd and friendly for a gluten-free diet, with gentle spices and a mild sweetness."}	gpt-5-nano	recipe-generation/3+recipe-name/1	1	\N	\N	\N	\N	2026-11-11 16:48:11.287846+00	2026-11-11 16:48:11.287846+00
f5133c33-db74-4516-b7f6-a9455fb77980	03bc23c2182a68f3a8a588ff8dfa9590ad7674c1c61f9e821ec594c607c62314	Pumpkin Pie	{"source": "recipe_search", "filters": {"dietary": ["Gluten-free"], "mealType": [], "servings": null, "maxMinutes": 30, "mustExclude": [], "mustInclude": [], "proteinType": [], "cookingMethod": []}, "timeMode": "total", "recipeName": "Pumpkin Pie", "schemaVersion": 1}	draft	{"tip": "Chill the tart shells for 15 minutes before baking to help them hold their shape.", "recipe": {"tags": ["ai-generated", "meal:dinner", "meal:lunch", "glutenFree"], "steps": ["Preheat oven to 190°C.", "Mix almond flour, sugar, and salt in a bowl. Stir in melted butter until the texture resembles wet sand.", "Press the almond crust evenly into three 8 cm tartlet pans or a muffin tin lined with parchment cups, creating a shallow edge.", "Bake crusts 8-10 minutes until lightly golden. Cool slightly.", "In a separate bowl, whisk pumpkin puree, coconut cream, eggs, vanilla, cinnamon, ginger, nutmeg, and salt until smooth.", "Divide the filling among the warm crusts. Bake 7-9 minutes until set but with a gentle wobble.", "Cool completely before serving; refrigerate briefly if you prefer firmer slices.", "Serve as small wedges or chilled slices with a dollop of whipped cream if desired."], "title": "Gluten-Free Pumpkin Pie Tartlets", "cookTime": 15, "prepTime": 15, "servings": "3-4", "ingredients": ["150 g almond flour (fine)", "40 g unsalted butter, melted", "2 tablespoons sugar (granulated)", "1/4 teaspoon salt", "200 g pumpkin puree", "120 ml coconut cream (unsweetened)", "2 eggs", "1 teaspoon vanilla extract", "1/2 teaspoon ground cinnamon", "1/4 teaspoon ground ginger", "1/8 teaspoon ground nutmeg", "1/8 teaspoon salt"]}, "description": "A gluten-free pumpkin pie in individual tartlets with a crisp almond crust and a lightly spiced pumpkin filling. Baked until just-set and silky, served warm or at room temperature for easy sharing."}	gpt-5-nano	recipe-generation/3+recipe-name/1	1	\N	\N	\N	\N	2026-11-11 16:48:51.908834+00	2026-11-11 16:48:51.908834+00
\.


--
-- Data for Name: recipe_nutrition; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recipe_nutrition (recipe_id, input_hash, data, analyzed_at) FROM stdin;
tablewise:real:v1:chicken-curry	901ebe89559b7d1bd5e072e549e518c1d4325bb2f4ec91cfdeccae254cbc2948	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 92, "carbsG": 46, "fiberG": 12, "sugarG": 22, "proteinG": 141, "caloriesKcal": 1595}, "version": 1, "inputHash": "901ebe89559b7d1bd5e072e549e518c1d4325bb2f4ec91cfdeccae254cbc2948", "analyzedAt": "2026-11-11T16:22:53.554Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.555254+00
tablewise:real:v1:salmon-egg-fried-rice	684b59c85734be1addb502bf49c184478e6db3f8aca822916f3d4f18239da7cd	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 46, "carbsG": 96, "fiberG": 9, "sugarG": 12, "proteinG": 55, "caloriesKcal": 1030}, "version": 1, "inputHash": "684b59c85734be1addb502bf49c184478e6db3f8aca822916f3d4f18239da7cd", "analyzedAt": "2026-11-11T16:22:53.556Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.557117+00
tablewise:real:v1:lentil-leek-soup	55a19b7ee5f18a6d9201834b3992d6568206ac0a6e75f6d770c41554058ece0a	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 4, "carbsG": 180, "fiberG": 28, "sugarG": 42, "proteinG": 47, "caloriesKcal": 920}, "version": 1, "inputHash": "55a19b7ee5f18a6d9201834b3992d6568206ac0a6e75f6d770c41554058ece0a", "analyzedAt": "2026-11-11T16:22:53.557Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.557947+00
tablewise:real:v1:baked-salmon	e5e12debe57f4cdc5548ca579dcfcbe0a5a77aee893ba23d5f2ba92b6d699347	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 84, "carbsG": 0, "fiberG": 0, "sugarG": 0, "proteinG": 112, "caloriesKcal": 1285}, "version": 1, "inputHash": "e5e12debe57f4cdc5548ca579dcfcbe0a5a77aee893ba23d5f2ba92b6d699347", "analyzedAt": "2026-11-11T16:22:53.558Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.558737+00
tablewise:real:v1:coconut-chickpea-curry	294143e07d62f1cbe93bd009b746f7f031a81e1e66fb74f484615ba2075a6dcf	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 112, "carbsG": 158, "fiberG": 40, "sugarG": 42, "proteinG": 51, "caloriesKcal": 1810}, "version": 1, "inputHash": "294143e07d62f1cbe93bd009b746f7f031a81e1e66fb74f484615ba2075a6dcf", "analyzedAt": "2026-11-11T16:22:53.559Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.559413+00
tablewise:real:v1:sundried-tomato-pasta	aabac82432219d34153d2bd3d24344d69b07bc9d6aa3a01f7eb8498196e0e541	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 64, "carbsG": 199, "fiberG": 13, "sugarG": 31, "proteinG": 57, "caloriesKcal": 1595}, "version": 1, "inputHash": "aabac82432219d34153d2bd3d24344d69b07bc9d6aa3a01f7eb8498196e0e541", "analyzedAt": "2026-11-11T16:22:53.559Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.559881+00
tablewise:catalog:v1:tofu-vegetable-stir-fry	6d856f4f690168857de903fbda54d57afebe0652a9fd6dcd2a28a5bc0568cff8	{"model": "claude-opus-5-5", "source": "ai-estimate", "totals": {"fatG": 90, "carbsG": 326, "fiberG": 25, "sugarG": 34, "proteinG": 111, "caloriesKcal": 2560}, "version": 1, "inputHash": "6d856f4f690168857de903fbda54d57afebe0652a9fd6dcd2a28a5bc0568cff8", "analyzedAt": "2026-11-21T04:05:00.000Z", "assumptions": ["Optional sesame seeds included.", "Rice weighed dry.", "Estimated by Claude from the ingredient list; standard nutrition tables."]}	2026-11-21 04:05:00.83212+00
tablewise:catalog:v1:flatbread-pizzas	9a651fbab83588552052f7a4320fdcb499988347668243230f77ac4065793b80	{"model": "claude-opus-5-5", "source": "ai-estimate", "totals": {"fatG": 80, "carbsG": 253, "fiberG": 15, "sugarG": 27, "proteinG": 100, "caloriesKcal": 2160}, "version": 1, "inputHash": "9a651fbab83588552052f7a4320fdcb499988347668243230f77ac4065793b80", "analyzedAt": "2026-11-21T04:05:00.000Z", "assumptions": ["Whole-milk natural yogurt.", "Dusting flour not counted.", "Estimated by Claude from the ingredient list; standard nutrition tables."]}	2026-11-21 04:05:00.83212+00
tablewise:catalog:v1:rice-noodle-salad	50409a61ec17d14f4c70a5ab9c8b867a024758508e404d89453db8a1c4c905bc	{"model": "claude-opus-5-5", "source": "ai-estimate", "totals": {"fatG": 87, "carbsG": 237, "fiberG": 17, "sugarG": 34, "proteinG": 99, "caloriesKcal": 2120}, "version": 1, "inputHash": "50409a61ec17d14f4c70a5ab9c8b867a024758508e404d89453db8a1c4c905bc", "analyzedAt": "2026-11-21T04:05:00.000Z", "assumptions": ["Rice noodles weighed dry.", "Carrots about 60 g each, cucumber about 300 g.", "Estimated by Claude from the ingredient list; standard nutrition tables."]}	2026-11-21 04:05:00.83212+00
tablewise:real:v1:spanish-omelette	dcdc4cf866ef1ffbedfb0b0623c2db70fa430fc4ee60d31ea4dea0befb376f80	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 75, "carbsG": 114, "fiberG": 17, "sugarG": 19, "proteinG": 68, "caloriesKcal": 1400}, "version": 1, "inputHash": "dcdc4cf866ef1ffbedfb0b0623c2db70fa430fc4ee60d31ea4dea0befb376f80", "analyzedAt": "2026-11-11T16:22:53.560Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.561039+00
tablewise:real:v1:sichuan-beef-stir-fry	0e239f40e94417a3122ab2a6966cd014a2a57fff8fc72019be29181bcec78811	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 71, "carbsG": 135, "fiberG": 13, "sugarG": 22, "proteinG": 80, "caloriesKcal": 1520}, "version": 1, "inputHash": "0e239f40e94417a3122ab2a6966cd014a2a57fff8fc72019be29181bcec78811", "analyzedAt": "2026-11-11T16:22:53.562Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.563258+00
tablewise:real:v1:spaghetti-meatballs	ba07bf687a0f035f9d6f252ee1f26d2faa9fa8e65010da5ea55c694367754058	{"model": "claude-sonnet-5-5", "source": "ai-estimate", "totals": {"fatG": 246, "carbsG": 443, "fiberG": 23, "sugarG": 38, "proteinG": 221, "caloriesKcal": 4860}, "version": 1, "inputHash": "ba07bf687a0f035f9d6f252ee1f26d2faa9fa8e65010da5ea55c694367754058", "analyzedAt": "2026-11-11T16:22:53.563Z", "assumptions": ["Estimated by Claude from the ingredient list using typical values for the stated quantities; not lab-analysed.", "Totals are for the whole recipe; the app divides by the stated servings.", "Optional 'to serve' items and salt/pepper to taste are excluded.", "Cooking oil and butter are counted in full, though some may stay in the pan."]}	2026-11-11 16:22:53.564006+00
tablewise:catalog:v1:aubergine-parmigiana	0be13d53d8982ac78afa7c002460115bd4173f13e85a3e450e0cf5cc9021a1e1	{"model": "claude-opus-5-5", "source": "ai-estimate", "totals": {"fatG": 140, "carbsG": 131, "fiberG": 47, "sugarG": 80, "proteinG": 98, "caloriesKcal": 2130}, "version": 1, "inputHash": "0be13d53d8982ac78afa7c002460115bd4173f13e85a3e450e0cf5cc9021a1e1", "analyzedAt": "2026-11-21T04:05:00.000Z", "assumptions": ["All 5 tbsp olive oil counted as eaten.", "Large aubergine about 400 g each.", "Whole-milk mozzarella.", "Estimated by Claude from the ingredient list; standard nutrition tables."]}	2026-11-21 04:05:00.83212+00
tablewise:synthetic:v1:021	dbf53e14f63c77e4979f2349c006f2aa4df23040f65d27d554e6cf8f001d46a2	{"model": "claude-opus-5-5", "source": "ai-estimate", "totals": {"fatG": 33, "carbsG": 198, "fiberG": 14, "sugarG": 20, "proteinG": 37, "caloriesKcal": 1240}, "version": 1, "inputHash": "dbf53e14f63c77e4979f2349c006f2aa4df23040f65d27d554e6cf8f001d46a2", "analyzedAt": "2026-11-21T04:05:00.000Z", "assumptions": ["No feta is listed in the ingredients, so none is counted.", "Courgette about 200 g.", "Estimated by Claude from the ingredient list; standard nutrition tables."]}	2026-11-21 04:05:00.83212+00
tablewise:catalog:v1:fish-pie	45639d79ff9284a47f906a07607ee20fef20f3a6cadf682f92956c13b3370c10	{"model": "claude-opus-5-5", "source": "ai-estimate", "totals": {"fatG": 130, "carbsG": 251, "fiberG": 24, "sugarG": 43, "proteinG": 179, "caloriesKcal": 2890}, "version": 1, "inputHash": "45639d79ff9284a47f906a07607ee20fef20f3a6cadf682f92956c13b3370c10", "analyzedAt": "2026-11-21T04:05:00.000Z", "assumptions": ["Fish pie mix about one third salmon.", "Whole milk, salted butter.", "Estimated by Claude from the ingredient list; standard nutrition tables."]}	2026-11-21 04:05:00.83212+00
tablewise:synthetic:v1:050	453915ce28a9483915058572c4789b58fe921a44a5c5c7cf8a0dcbfdd89d6416	{"model": "claude-opus-5-5", "source": "ai-estimate", "totals": {"fatG": 88, "carbsG": 238, "fiberG": 5, "sugarG": 86, "proteinG": 36, "caloriesKcal": 1900}, "version": 1, "inputHash": "453915ce28a9483915058572c4789b58fe921a44a5c5c7cf8a0dcbfdd89d6416", "analyzedAt": "2026-11-21T04:05:00.000Z", "assumptions": ["All 80 ml oil counted as eaten.", "Whole milk; medium eggs.", "Estimated by Claude from the ingredient list; standard nutrition tables."]}	2026-11-21 04:05:00.83212+00
tablewise:catalog:v1:pork-schnitzel	fdde3f50ff6cd2e11a11b128e4e30c7fb710c18d5c55819e11850924e2062fc1	{"model": "claude-opus-5-5", "source": "ai-estimate", "totals": {"fatG": 100, "carbsG": 245, "fiberG": 18, "sugarG": 11, "proteinG": 175, "caloriesKcal": 2620}, "version": 1, "inputHash": "fdde3f50ff6cd2e11a11b128e4e30c7fb710c18d5c55819e11850924e2062fc1", "analyzedAt": "2026-11-21T04:05:00.000Z", "assumptions": ["Pork steaks about 150 g each, trimmed.", "About half of the 6 tbsp frying oil absorbed.", "Estimated by Claude from the ingredient list; standard nutrition tables."]}	2026-11-21 04:05:00.83212+00
tablewise:synthetic:v1:002	ff2ba2b835f4977cbbcbcfaf16f942d5f288e50da2d8d1d329db789f3c0e3ca3	{"model": "claude-opus-5-5", "source": "ai-estimate", "totals": {"fatG": 43, "carbsG": 190, "fiberG": 10, "sugarG": 12, "proteinG": 56, "caloriesKcal": 1380}, "version": 1, "inputHash": "ff2ba2b835f4977cbbcbcfaf16f942d5f288e50da2d8d1d329db789f3c0e3ca3", "analyzedAt": "2026-11-21T04:05:00.000Z", "assumptions": ["One 90 g drained tin of sardines in oil.", "Parsley negligible.", "Estimated by Claude from the ingredient list; standard nutrition tables."]}	2026-11-21 04:05:00.83212+00
tablewise:synthetic:v1:006	6f8364d04101413b891e0f7bcc37e96651c45d4a5d61eeafe2de1cce1e9f94ee	{"model": "claude-opus-5-5", "source": "ai-estimate", "totals": {"fatG": 33, "carbsG": 198, "fiberG": 14, "sugarG": 20, "proteinG": 37, "caloriesKcal": 1240}, "version": 1, "inputHash": "6f8364d04101413b891e0f7bcc37e96651c45d4a5d61eeafe2de1cce1e9f94ee", "analyzedAt": "2026-11-21T04:05:00.000Z", "assumptions": ["Courgette about 200 g.", "Salt and pepper negligible.", "Estimated by Claude from the ingredient list; standard nutrition tables."]}	2026-11-21 04:05:00.83212+00
tablewise:catalog:v1:slow-cooker-pulled-pork	bef31e9043cc31119120c7d961ec179494557a4c2ba694e2d746ca5197085f8c	{"model": "claude-opus-5-5", "source": "ai-estimate", "totals": {"fatG": 250, "carbsG": 283, "fiberG": 18, "sugarG": 109, "proteinG": 308, "caloriesKcal": 4650}, "version": 1, "inputHash": "bef31e9043cc31119120c7d961ec179494557a4c2ba694e2d746ca5197085f8c", "analyzedAt": "2026-11-21T04:05:00.000Z", "assumptions": ["Optional coleslaw included.", "Burger buns about 60 g each.", "Trimmed pork shoulder about 200 kcal per 100 g raw.", "Estimated by Claude from the ingredient list; standard nutrition tables."]}	2026-11-21 04:05:00.83212+00
\.


--
-- Data for Name: recipe_translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recipe_translations (recipe_id, language, title, ingredients, steps, translated_by, created_at) FROM stdin;
tablewise:catalog:v1:aubergine-parmigiana	ru	Баклажаны по-пармски (пармиджана)	{"3 крупных баклажана, нарезанных вдоль","5 ст. л. оливкового масла, разделить","1 луковица, мелко нарезанная","3 зубчика чеснока, раздавленных","800 г консервированных резаных томатов","1 ст. л. томатного пюре","1 ч. л. сахара","0,75 ч. л. соли","20 г свежего базилика, листья порвать","250 г моцареллы, обсушить и порвать","60 г вегетарианского твёрдого сыра, мелко натереть"}	{"Разогрейте духовку до 220 °C (200 °C с конвекцией). Нарежьте баклажаны ломтиками толщиной около 1 см, смажьте с обеих сторон 4 ст. л. масла, разложите на два противня и запекайте 20–25 минут, один раз перевернув, до мягкости и золотистого цвета.","Тем временем разогрейте оставшееся масло в сотейнике на среднем огне. Готовьте лук 6–8 минут до мягкости, затем добавьте чеснок на 1 минуту.","Добавьте томаты, томатное пюре, сахар и соль и тушите 15 минут, пока соус не загустеет. Вмешайте бо́льшую часть базилика.","Уменьшите температуру духовки до 190 °C (170 °C с конвекцией). В форме для запекания выложите слоями немного соуса, затем баклажаны, моцареллу и немного твёрдого сыра. Повторите слои, закончив соусом и оставшимся твёрдым сыром.","Запекайте 30–35 минут, пока не забулькает и верх не станет золотистым. Дайте постоять 10 минут, посыпьте оставшимся базиликом и подавайте."}	ai	2026-11-20 15:44:58.082319+00
tablewise:catalog:v1:aubergine-parmigiana	he	פרמיג'אנה חצילים	{"3 חצילים גדולים, פרוסים לאורכם","5 כפות שמן זית, מחולקות","1 בצל, קצוץ דק","3 שיני שום, כתושות","800 גרם עגבניות קצוצות משומרות","1 כף רסק עגבניות","1 כפית סוכר","0.75 כפית מלח","20 גרם בזיליקום טרי, עלים קרועים","250 גרם מוצרלה, מסוננת וקרועה","60 גרם גבינה קשה צמחונית, מגוררת דק"}	{"חממו את התנור ל-220 מעלות (200 מעלות בטורבו). פרסו את החצילים לפרוסות בעובי של כ-1 ס\\"מ, הברישו את שני הצדדים ב-4 כפות מהשמן, פזרו על שתי תבניות וצלו 20–25 דקות, תוך היפוך אחד, עד שהם רכים וזהובים.","בינתיים חממו את שארית השמן בסיר על אש בינונית. בשלו את הבצל 6–8 דקות עד שהוא מתרכך, ואז הוסיפו את השום לדקה אחת.","הוסיפו את העגבניות, רסק העגבניות, הסוכר והמלח ובשלו על אש קטנה 15 דקות עד שהרוטב מסמיך. ערבבו פנימה את רוב הבזיליקום.","הנמיכו את התנור ל-190 מעלות (170 מעלות בטורבו). בתבנית אפייה סדרו שכבה של מעט רוטב, ואז חצילים, מוצרלה ומעט גבינה קשה. חזרו על השכבות וסיימו ברוטב ובשארית הגבינה הקשה.","אפו 30–35 דקות, עד שהתבשיל מבעבע והחלק העליון זהוב. תנו לו לנוח 10 דקות, פזרו את שארית הבזיליקום והגישו."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:sichuan-beef-stir-fry	ru	Говядина с сычуаньским перцем в воке	{"2 ст. л. рапсового масла","300 г стейка, тонко нарезанного","1 ст. л. кукурузного крахмала","2 разноцветных перца, нарезанных","200 г мини-кукурузы, разрезанной пополам","2 небольшие красные луковицы, нарезанные","0,5 ч. л. хлопьев чили","1 ч. л. сычуаньского перца, молотого","2 ст. л. тёмного соевого соуса с пониженным содержанием соли","1 ст. л. масла чили, по желанию","300 г готового бурого риса басмати"}	{"Измельчите сычуаньский перец в ступке.","Разогрейте 1 столовую ложку рапсового масла в большом воке. Добавьте стейк и крахмал, перемешайте, чтобы покрыть, и обжаривайте 2–3 минуты до румяности; переложите на тарелку.","Добавьте оставшееся масло, перец, мини-кукурузу и лук. Обжаривайте 3–4 минуты, затем верните говядину с соком, хлопья чили и сычуаньский перец.","Готовьте 1 минуту, добавьте соевый соус и 50 мл воды и перемешивайте, пока соус не покроет всё. Подавайте с готовым рисом и маслом чили по желанию."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:sichuan-beef-stir-fry	he	מוקפץ בקר עם פלפל סצ'ואן	{"2 כפות שמן קנולה","300 גרם סטייק, פרוס דק","1 כף קורנפלור","2 פלפלים בצבעים שונים, פרוסים","200 גרם תירס גמדי, חצוי","2 בצלים סגולים קטנים, פרוסים","0.5 כפית פתיתי צ'ילי","1 כפית פלפל סצ'ואן, טחון","2 כפות רוטב סויה כהה דל נתרן","1 כף שמן צ'ילי, לא חובה","300 גרם אורז בסמטי מלא מבושל"}	{"טחנו את פלפל הסצ'ואן במכתש ועלי.","חממו כף אחת שמן קנולה בווק גדול. הוסיפו את הסטייק והקורנפלור, ערבבו לציפוי וטגנו 2–3 דקות עד להשחמה; העבירו לצלחת.","הוסיפו את שארית השמן, הפלפלים, התירס הגמדי והבצל. הקפיצו 3–4 דקות, ואז החזירו את הבקר עם הנוזלים שלו, פתיתי הצ'ילי ופלפל הסצ'ואן.","בשלו דקה אחת, הוסיפו את רוטב הסויה ו-50 מ\\"ל מים וערבבו עד שהרוטב מצפה הכול. הגישו עם האורז המוכן ועם שמן צ'ילי לפי הרצון."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:coconut-chickpea-curry	ru	Карри из нута и кейла на кокосовом молоке	{"1,5 ст. л. порошка карри","1 ч. л. зиры","1 жёлтая луковица, нарезанная кубиками","2 зубчика чеснока, мелко нарубленных","1 ч. л. свежего имбиря, натёртого","2 ст. л. оливкового масла","2 банки нута (по 15 унц.), слить жидкость","1 банка томатного соуса (8 унц.)","1 банка жирного кокосового молока (13,5 унц.)","4 унц. кейла, нарезанного","Соль по вкусу","Готовый рис или хлеб для подачи, по желанию"}	{"Нарежьте лук кубиками, мелко нарубите чеснок, натрите имбирь и нарежьте кейл.","Обжарьте порошок карри и зиру на сухой глубокой сковороде на огне ниже среднего примерно 1 минуту.","Добавьте оливковое масло, лук, чеснок и имбирь; готовьте до мягкости около 5 минут. Вмешайте нут, томатный соус и кокосовое молоко.","Доведите до лёгкого кипения, убавьте огонь и готовьте 15 минут, иногда помешивая.","Добавьте кейл и готовьте ещё около 5 минут, до мягкости. Посолите по вкусу и по желанию подайте отдельно приготовленный рис или хлеб."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:coconut-chickpea-curry	he	קארי חומוס וקייל בחלב קוקוס	{"1.5 כפות אבקת קארי","1 כפית כמון","1 בצל צהוב, קצוץ לקוביות","2 שיני שום, קצוצות דק","1 כפית ג'ינג'ר טרי, מגורר","2 כפות שמן זית","2 פחיות גרגרי חומוס (15 אונקיות כל אחת), מסוננות","1 פחית רוטב עגבניות (8 אונקיות)","1 פחית חלב קוקוס מלא (13.5 אונקיות)","4 אונקיות קייל, קצוץ","מלח לפי הטעם","אורז מבושל או לחם להגשה, לא חובה"}	{"קצצו את הבצל לקוביות, קצצו דק את השום, גררו את הג'ינג'ר וקצצו את הקייל.","קלו את אבקת הקארי והכמון במחבת עמוקה יבשה על אש בינונית-נמוכה כדקה.","הוסיפו את שמן הזית, הבצל, השום והג'ינג'ר; רככו כ-5 דקות. ערבבו פנימה את גרגרי החומוס המסוננים, רוטב העגבניות וחלב הקוקוס.","הביאו לרתיחה עדינה, הנמיכו את האש ובשלו 15 דקות תוך ערבוב מדי פעם.","הוסיפו את הקייל ובשלו עוד כ-5 דקות, עד שהוא מתרכך. המליחו לפי הטעם והגישו בצד אורז או לחם לפי הרצון."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:chicken-curry	ru	Простое куриное карри	{"2 ст. л. подсолнечного масла","1 луковица, тонко нарезанная","2 зубчика чеснока, раздавленных","1 кусочек имбиря размером с большой палец, натёртый","6 куриных бёдер без кости и кожи","3 ст. л. пасты карри средней остроты","400 г консервированных резаных томатов","100 г греческого йогурта","1 небольшой пучок кинзы, нарубленной","50 г молотого миндаля","Соль по вкусу","Лепёшка наан или готовый рис басмати для подачи, по желанию"}	{"В большой сковороде готовьте лук в масле со щепоткой соли на среднем огне 8–10 минут до мягкости.","Вмешайте чеснок и имбирь на 1 минуту. Нарежьте курицу кусками примерно по 3 см и обжаривайте на сковороде 5 минут.","Добавьте пасту карри, томаты и 250 мл воды. Доведите до кипения, затем тушите без крышки 25–30 минут, пока соус не загустеет, а курица не приготовится полностью.","Вмешайте йогурт, кинзу и молотый миндаль. Доведите до вкуса и подавайте; наан или отдельно приготовленный рис — по желанию."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:chicken-curry	he	קארי עוף קל	{"2 כפות שמן חמניות","1 בצל, פרוס דק","2 שיני שום, כתושות","1 חתיכת ג'ינג'ר בגודל אגודל, מגוררת","6 ירכי עוף ללא עור וללא עצם","3 כפות משחת קארי בחריפות בינונית","400 גרם עגבניות קצוצות משומרות","100 גרם יוגורט יווני","1 צרור קטן כוסברה, קצוצה","50 גרם שקדים טחונים","מלח לפי הטעם","לחם נאן או אורז בסמטי מבושל להגשה, לא חובה"}	{"במחבת גדולה רככו את הבצל בשמן עם קורט מלח על אש בינונית 8–10 דקות.","ערבבו פנימה את השום והג'ינג'ר לדקה אחת. חתכו את העוף לחתיכות של כ-3 ס\\"מ וטגנו במחבת 5 דקות.","הוסיפו את משחת הקארי, העגבניות ו-250 מ\\"ל מים. הביאו לרתיחה ובשלו ללא מכסה 25–30 דקות, עד שהרוטב מסמיך והעוף מבושל לגמרי.","ערבבו פנימה את היוגורט, הכוסברה והשקדים הטחונים. תקנו תיבול והגישו; נאן או אורז מבושל בנפרד לפי הרצון."}	ai	2026-11-20 15:44:58.082319+00
tablewise:synthetic:v1:021	ru	Паста с фетой и томатами	{"250 г сухой пасты","2 ст. л. оливкового масла","2 зубчика чеснока, мелко нарубленных","300 г томатов, нарезанных","1 небольшой цукини или сладкий перец, нарезанный кубиками","1 ч. л. сушёных трав","Соль и перец по вкусу"}	{"Отварите пасту по инструкции на упаковке; откиньте.","Разогрейте масло, обжарьте чеснок и овощи до мягкости.","Добавьте томаты и травы и тушите 10 минут.","Смешайте соус с пастой; приправьте и подавайте."}	ai	2026-11-20 15:44:58.082319+00
tablewise:synthetic:v1:021	he	פסטה עם פטה ועגבניות	{"250 גרם פסטה יבשה","2 כפות שמן זית","2 שיני שום, קצוצות דק","300 גרם עגבניות, קצוצות","1 קישוא קטן או פלפל, קצוץ לקוביות","1 כפית עשבי תיבול יבשים","מלח ופלפל לפי הטעם"}	{"בשלו את הפסטה לפי ההוראות שעל האריזה; סננו.","חממו שמן, הזהיבו את השום והירקות עד שהם מתרככים.","הוסיפו את העגבניות ועשבי התיבול ובשלו על אש קטנה 10 דקות.","ערבבו את הרוטב עם הפסטה; תבלו והגישו."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:sundried-tomato-pasta	he	פסטה קרמית עם עגבניות מיובשות בסיר אחד	{"0.5 כוס עגבניות מיובשות","2 כפות חמאה","2 שיני שום, קצוצות דק","8 אונקיות פטוצ'יני","0.5 כפית בזיליקום יבש","פלפל שחור לפי הטעם","2 כוסות ציר עוף","2 אונקיות גבינת שמנת","1 כוס חלב מלא","0.25 כוס פרמזן מגורר"}	{"קצצו את העגבניות המיובשות. המיסו את החמאה במחבת עמוקה וטגנו בעדינות את השום כדקה.","הוסיפו את הפסטה, העגבניות, הבזיליקום, הפלפל וציר העוף. שברו את הפסטה במידת הצורך כדי שתהיה בתוך הנוזל.","כסו, הביאו לרתיחה ואז הנמיכו לבעבוע עדין. ערבבו כל כמה דקות והחזירו את המכסה.","בשלו 7–10 דקות עד שהפסטה רכה ורוב הציר נספג. על אש נמוכה המיסו פנימה את גבינת השמנת, ואז ערבבו פנימה את החלב והפרמזן כדי להשלים את הרוטב."}	ai	2026-11-20 15:44:58.082319+00
tablewise:catalog:v1:fish-pie	ru	Рыбный пирог	{"1 кг рассыпчатого картофеля, очищенного и нарезанного крупными кусками","90 г сливочного масла, разделить","600 мл цельного молока, разделить","40 г пшеничной муки","1 лавровый лист","450 г рыбного ассорти (треска, лосось и копчёная пикша без кожи)","150 г сырых очищенных креветок","150 г замороженного горошка","2 ст. л. свежей петрушки, нарубленной","50 г выдержанного чеддера, натёртого","0,5 ч. л. соли","0,25 ч. л. чёрного перца"}	{"Разогрейте духовку до 200 °C (180 °C с конвекцией). Отварите картофель в большой кастрюле подсоленной воды 15–18 минут до мягкости, слейте воду и разомните с 50 г масла и 100 мл молока. Посолите половиной соли.","Тем временем растопите оставшиеся 40 г масла в сотейнике на среднем огне, вмешайте муку и готовьте 1 минуту. Постепенно, взбивая, влейте оставшиеся 500 мл молока, добавьте лавровый лист и варите, помешивая, 3–4 минуты, пока соус не станет гладким и густым. Выньте лавровый лист и приправьте оставшейся солью и перцем.","Распределите сырую рыбу, креветки и горошек по дну формы для запекания объёмом около 2 литров. Вмешайте петрушку в соус и равномерно залейте.","Выложите пюре сверху, начиная с краёв, чтобы закрыть начинку, затем взрыхлите поверхность вилкой и посыпьте сыром.","Поставьте форму на противень и запекайте 30–35 минут, пока верх не станет золотистым, а по краям не забулькает, рыба не станет непрозрачной и легко расслаивающейся, а креветки — полностью розовыми. Дайте постоять 5 минут перед подачей.","Чтобы приготовить заранее, остудите собранный незапечённый пирог, накройте и уберите в холодильник до 24 часов, затем запекайте 45–50 минут, пока он не прогреется насквозь."}	ai	2026-11-20 15:44:58.082319+00
tablewise:catalog:v1:fish-pie	he	פשטידת דגים	{"1 ק\\"ג תפוחי אדמה קמחיים, קלופים וחתוכים לגושים","90 גרם חמאה, מחולקת","600 מ\\"ל חלב מלא, מחולק","40 גרם קמח לבן","1 עלה דפנה","450 גרם תערובת דגים לפשטידה (בקלה, סלמון והדוק מעושן, ללא עור)","150 גרם שרימפס נא קלופים","150 גרם אפונה קפואה","2 כפות פטרוזיליה טרייה, קצוצה","50 גרם צ'דר מיושן, מגורר","0.5 כפית מלח","0.25 כפית פלפל שחור"}	{"חממו את התנור ל-200 מעלות (180 מעלות בטורבו). בשלו את תפוחי האדמה בסיר גדול עם מים מומלחים 15–18 דקות עד שהם רכים, סננו ומעכו עם 50 גרם מהחמאה ו-100 מ\\"ל מהחלב. תבלו בחצי מהמלח.","בינתיים המיסו את 40 הגרם הנותרים של החמאה בסיר על אש בינונית, ערבבו פנימה את הקמח ובשלו דקה אחת. הוסיפו בהדרגה, תוך טריפה, את 500 מ\\"ל החלב הנותרים, הוסיפו את עלה הדפנה ובשלו על אש קטנה תוך ערבוב 3–4 דקות עד שהרוטב חלק וסמיך. הוציאו את עלה הדפנה ותבלו בשארית המלח ובפלפל.","פזרו את הדגים הנאים, השרימפס והאפונה על תחתית תבנית אפייה של כ-2 ליטר. ערבבו את הפטרוזיליה לתוך הרוטב ויצקו אותו באופן אחיד.","מרחו את הפירה מעל, החל מהשוליים כדי לאטום, ואז חספסו את פני השטח במזלג ופזרו את הגבינה.","הניחו את התבנית על מגש אפייה ואפו 30–35 דקות, עד שהפשטידה זהובה ומבעבעת בשוליים, הדג אטום ומתפרק בקלות והשרימפס ורודים לגמרי. תנו לה לנוח 5 דקות לפני ההגשה.","להכנה מראש: צננו את הפשטידה המורכבת שלא נאפתה, כסו ושמרו במקרר עד 24 שעות, ואז אפו 45–50 דקות עד שהיא חמה מאוד במרכז."}	ai	2026-11-20 15:44:58.082319+00
tablewise:synthetic:v1:050	ru	Мичиганский сэндвич из французского тоста	{"200 г пшеничной муки","80 г сахара","2 яйца","100 мл молока","80 мл растительного масла без запаха","1 ч. л. разрыхлителя","1 ч. л. ванильного экстракта"}	{"Разогрейте духовку до 180 °C (356 °F) и подготовьте форму для выпечки или для маффинов.","Взбейте яйца, молоко, масло, сахар и ваниль.","Аккуратно вмешайте муку и разрыхлитель до однородности.","Выпекайте до золотистого цвета, пока шпажка не будет выходить сухой; остудите перед подачей."}	ai	2026-11-20 15:44:58.082319+00
tablewise:synthetic:v1:050	he	כריך פרנץ' טוסט בסגנון מישיגן	{"200 גרם קמח לבן","80 גרם סוכר","2 ביצים","100 מ\\"ל חלב","80 מ\\"ל שמן ניטרלי","1 כפית אבקת אפייה","1 כפית תמצית וניל"}	{"חממו את התנור ל-180 מעלות (356°F) והכינו תבנית אפייה או תבנית מאפינס.","טרפו את הביצים, החלב, השמן, הסוכר והווניל.","קפלו פנימה את הקמח ואבקת האפייה רק עד שהתערובת אחידה.","אפו עד להזהבה ועד ששיפוד יוצא נקי; צננו לפני ההגשה."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:sundried-tomato-pasta	ru	Сливочная паста с вялеными томатами в одной кастрюле	{"0,5 стак. вяленых томатов","2 ст. л. сливочного масла","2 зубчика чеснока, мелко нарубленных","8 унц. феттучине","0,5 ч. л. сушёного базилика","Чёрный перец по вкусу","2 стак. куриного бульона","2 унц. сливочного сыра","1 стак. цельного молока","0,25 стак. тёртого пармезана"}	{"Нарежьте вяленые томаты. Растопите масло в глубокой сковороде и слегка обжарьте чеснок около 1 минуты.","Добавьте пасту, томаты, базилик, перец и куриный бульон. При необходимости разломайте пасту, чтобы она была в жидкости.","Накройте крышкой, доведите до кипения, затем убавьте огонь до слабого. Помешивайте каждые несколько минут и снова накрывайте.","Готовьте 7–10 минут, пока паста не станет мягкой, а бульон почти не впитается. На слабом огне растопите сливочный сыр, затем вмешайте молоко и пармезан, чтобы получился соус."}	ai	2026-11-20 15:44:58.082319+00
tablewise:catalog:v1:pork-schnitzel	ru	Свиной шницель	{"750 г молодого картофеля, крупные разрезать пополам","15 г сливочного масла","1 ст. л. свежей петрушки, нарубленной","4 стейка из свиной корейки без кости, срезать жир","50 г пшеничной муки","0,5 ч. л. соли","0,25 ч. л. чёрного перца","2 яйца","100 г панировочных сухарей панко","6 ст. л. растительного масла","1 лимон, нарезанный дольками"}	{"Отварите картофель в большой кастрюле подсоленной воды 15–18 минут до мягкости. Слейте воду и перемешайте с маслом и петрушкой; держите в тепле.","Тем временем положите каждый стейк между двумя листами пергамента и отбейте скалкой до толщины около 5 мм.","Подготовьте три неглубокие миски: мука с солью и перцем, взбитые яйца и сухари. Обваляйте каждый стейк в муке, затем в яйце, затем в сухарях, прижимая, чтобы панировка держалась. Вымойте руки и доску после работы с сырой свининой.","Разогрейте половину масла в большой сковороде на огне выше среднего. Жарьте два шницеля по 2–3 минуты с каждой стороны до насыщенного золотистого цвета и полной готовности (не менее 63 °C в центре). Обсушите на бумажном полотенце и повторите с оставшимся маслом и свининой.","Дайте шницелям постоять 3 минуты, затем подавайте с картофелем и дольками лимона."}	ai	2026-11-20 15:44:58.082319+00
tablewise:catalog:v1:pork-schnitzel	he	שניצל חזיר	{"750 גרם תפוחי אדמה צעירים, הגדולים חצויים","15 גרם חמאה","1 כף פטרוזיליה טרייה, קצוצה","4 סטייקים של מותן חזיר ללא עצם, שומן מוסר","50 גרם קמח לבן","0.5 כפית מלח","0.25 כפית פלפל שחור","2 ביצים","100 גרם פירורי לחם פנקו","6 כפות שמן צמחי","1 לימון, חתוך לפלחים"}	{"בשלו את תפוחי האדמה בסיר גדול עם מים מומלחים 15–18 דקות עד שהם רכים. סננו וערבבו עם החמאה והפטרוזיליה; שמרו חמים.","בינתיים הניחו כל סטייק בין שני דפי אפייה והכו במערוך עד לעובי של כ-5 מ\\"מ.","הכינו שלוש צלחות רדודות: הקמח מעורבב עם המלח והפלפל, הביצים טרופות ופירורי הלחם. צפו כל סטייק בקמח, אחר כך בביצה ואז בפירורים, תוך לחיצה כדי שיידבקו. שטפו ידיים וקרש אחרי טיפול בבשר חזיר נא.","חממו חצי מהשמן במחבת גדולה על אש בינונית-גבוהה. טגנו שני שניצלים 2–3 דקות מכל צד, עד שהם זהובים עמוקים ומבושלים לגמרי (לפחות 63 מעלות במרכז). הניחו על נייר סופג וחזרו עם שארית השמן והבשר.","תנו לשניצלים לנוח 3 דקות, ואז הגישו עם תפוחי האדמה ופלחי הלימון לסחיטה."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:lentil-leek-soup	ru	Суп из красной чечевицы, моркови и лука-порея	{"2 литра овощного бульона","150 г красной чечевицы","6 морковок, мелко нарезанных","2 средних стебля лука-порея, нарезанных (около 300 г)","1 небольшая горсть петрушки, нарубленной","Соль и чёрный перец по вкусу"}	{"Разогрейте овощной бульон в большой кастрюле и вмешайте красную чечевицу.","Доведите до кипения и дайте чечевице начать размягчаться несколько минут.","Добавьте морковь и лук-порей, приправьте по вкусу, накройте и варите на слабом огне 45–60 минут, пока овощи не станут мягкими, а чечевица не разварится.","Посыпьте каждую порцию петрушкой. Источник допускает и бульон на ветчине; в этой версии выбран вегетарианский овощной бульон."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:lentil-leek-soup	he	מרק עדשים כתומות, גזר וכרישה	{"2 ליטר ציר ירקות","150 גרם עדשים כתומות","6 גזרים, קצוצים דק","2 כרישות בינוניות, פרוסות (כ-300 גרם)","1 חופן קטן פטרוזיליה, קצוצה","מלח ופלפל שחור לפי הטעם"}	{"חממו את ציר הירקות בסיר גדול וערבבו פנימה את העדשים הכתומות.","הביאו לרתיחה ותנו לעדשים להתחיל להתרכך כמה דקות.","הוסיפו את הגזר והכרישה, תבלו לפי הטעם, כסו ובשלו על אש קטנה 45–60 דקות עד שהירקות רכים והעדשים מתפרקות.","פזרו פטרוזיליה על כל מנה. המקור מתיר גם ציר חזיר; גרסה זו משתמשת באפשרות הצמחונית של ציר ירקות."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:salmon-egg-fried-rice	ru	Жареный рис с лососем и яйцом	{"1 кусочек имбиря размером с большой палец, натёртый","1–2 зубчика чеснока, натёртых","2 ст. л. соевого соуса с пониженным содержанием соли","0,5 ст. л. рисового уксуса","2 ст. л. растительного масла","1 крупная морковь, нарезанная","175 г мини-кукурузы и сахарного горошка, нарезанных","2 филе копчёного лосося без кожи","250 г готового бурого риса басмати в пакете","2 яйца","Острый соус для подачи, по желанию"}	{"Смешайте в миске имбирь, чеснок, соевый соус и уксус.","Разогрейте большой вок с 1 столовой ложкой масла. Добавьте морковь, овощную смесь и лосось; готовьте рыбу примерно по 2 минуты с каждой стороны.","Вмешайте готовый рис, разделяя рыбу на кусочки. Сдвиньте смесь в сторону, добавьте оставшееся масло и пожарьте яйца-болтунью на освободившемся месте.","Перемешайте всё с соевой смесью и хорошо прогрейте несколько минут. Острый соус подайте отдельно."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:salmon-egg-fried-rice	he	אורז מטוגן עם סלמון וביצה	{"1 חתיכת ג'ינג'ר בגודל אגודל, מגוררת","1–2 שיני שום, מגוררות","2 כפות רוטב סויה דל נתרן","0.5 כף חומץ אורז","2 כפות שמן צמחי","1 גזר גדול, קצוץ","175 גרם תירס גמדי ואפונת שלג, קצוצים","2 פילה סלמון מעושן ללא עור","250 גרם שקית אורז בסמטי מלא מבושל","2 ביצים","רוטב חריף להגשה, לא חובה"}	{"ערבבו בקערה את הג'ינג'ר, השום, רוטב הסויה והחומץ.","חממו ווק גדול עם כף אחת שמן. הוסיפו את הגזר, הירקות והסלמון; בשלו את הדג כ-2 דקות מכל צד.","ערבבו פנימה את האורז המוכן תוך פירוק הדג לפתיתים. דחפו את התערובת הצידה, הוסיפו את שארית השמן וטרפו את הביצים במקום הפנוי.","ערבבו הכול יחד עם תערובת הסויה וחממו היטב כמה דקות. הגישו רוטב חריף בצד."}	ai	2026-11-20 15:44:58.082319+00
tablewise:synthetic:v1:002	ru	Лингвини с сардинами	{"250 г сухой пасты","1 банка сардин или скумбрии, слить жидкость (или 300 г очищенных мидий)","2 зубчика чеснока, мелко нарубленных","200 г томатов черри","2 ст. л. оливкового масла","1 ст. л. лимонного сока","Рубленая петрушка по вкусу"}	{"Отварите пасту в подсоленной воде и оставьте немного воды от варки.","Прогрейте масло с чесноком, затем размягчите томаты на сковороде.","Добавьте рыбу и прогрейте или готовьте мидии, пока не раскроются; нераскрывшиеся мидии выбросьте.","Перемешайте с пастой, лимонным соком и петрушкой; разбавьте водой от пасты."}	ai	2026-11-20 15:44:58.082319+00
tablewise:synthetic:v1:002	he	לינגוויני עם סרדינים	{"250 גרם פסטה יבשה","1 קופסת סרדינים או מקרל, מסוננת (או 300 גרם מולים נקיים)","2 שיני שום, קצוצות דק","200 גרם עגבניות שרי","2 כפות שמן זית","1 כף מיץ לימון","פטרוזיליה קצוצה לפי הטעם"}	{"בשלו את הפסטה במים מומלחים ושמרו מעט ממי הבישול.","חממו שמן ושום, ואז רככו את העגבניות במחבת.","הוסיפו את הדג וחממו, או בשלו את המולים עד שהם נפתחים; השליכו מולים שלא נפתחו.","ערבבו עם הפסטה, מיץ הלימון והפטרוזיליה; דללו במי הפסטה."}	ai	2026-11-20 15:44:58.082319+00
tablewise:synthetic:v1:006	ru	Простая паста арраббьята	{"250 г сухой пасты","2 ст. л. оливкового масла","2 зубчика чеснока, мелко нарубленных","300 г томатов, нарезанных","1 небольшой цукини или сладкий перец, нарезанный кубиками","1 ч. л. сушёных трав","Соль и перец по вкусу"}	{"Отварите пасту по инструкции на упаковке; откиньте.","Разогрейте масло, обжарьте чеснок и овощи до мягкости.","Добавьте томаты и травы и тушите 10 минут.","Смешайте соус с пастой; приправьте и подавайте."}	ai	2026-11-20 15:44:58.082319+00
tablewise:synthetic:v1:006	he	פסטה ארביאטה פשוטה	{"250 גרם פסטה יבשה","2 כפות שמן זית","2 שיני שום, קצוצות דק","300 גרם עגבניות, קצוצות","1 קישוא קטן או פלפל, קצוץ לקוביות","1 כפית עשבי תיבול יבשים","מלח ופלפל לפי הטעם"}	{"בשלו את הפסטה לפי ההוראות שעל האריזה; סננו.","חממו שמן, הזהיבו את השום והירקות עד שהם מתרככים.","הוסיפו את העגבניות ועשבי התיבול ובשלו על אש קטנה 10 דקות.","ערבבו את הרוטב עם הפסטה; תבלו והגישו."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:baked-salmon	ru	Простой запечённый лосось	{"4 филе лосося без кожи","1 ст. л. оливкового масла","Соль и чёрный перец по вкусу","Рубленая зелень для подачи, по желанию","Ломтики лимона для подачи, по желанию","Брокколи на пару для подачи, по желанию"}	{"Разогрейте духовку до 180 °C (160 °C с конвекцией). Смажьте лосось оливковым маслом и приправьте.","Выложите филе в жаропрочную форму. Накройте, чтобы рыба получилась мягче, или оставьте открытой для лёгкой корочки.","Запекайте 10–15 минут, в зависимости от толщины, пока рыба не станет непрозрачной и не начнёт легко расслаиваться.","Подавайте с зеленью, лимоном и отдельно приготовленной на пару брокколи по желанию. Количество гарнира в источнике не указано."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:baked-salmon	he	סלמון אפוי פשוט	{"4 פילה סלמון ללא עור","1 כף שמן זית","מלח ופלפל שחור לפי הטעם","עשבי תיבול קצוצים להגשה, לא חובה","פרוסות לימון להגשה, לא חובה","ברוקולי באדים להגשה, לא חובה"}	{"חממו את התנור ל-180 מעלות (160 מעלות בטורבו). הברישו את הסלמון בשמן זית ותבלו.","סדרו את הפילה בתבנית חסינת תנור. כסו לקבלת מרקם רך יותר, או השאירו ללא כיסוי לפני שטח צלוי קלות.","אפו 10–15 דקות, בהתאם לעובי, עד שהדג אטום ומתפרק בקלות.","הגישו עם עשבי התיבול, הלימון והברוקולי המאודה בנפרד לפי הרצון. כמות התוספות אינה קבועה במקור."}	ai	2026-11-20 15:44:58.082319+00
tablewise:catalog:v1:slow-cooker-pulled-pork	ru	Рваная свинина в медленноварке	{"1,5 кг свиной лопатки без кости, без шкуры и лишнего жира","2 ст. л. мягкого коричневого сахара","2 ч. л. копчёной паприки","1 ч. л. молотой зиры","1 ч. л. гранулированного чеснока","1,5 ч. л. соли","0,5 ч. л. чёрного перца","1 луковица, нарезанная","200 г пассаты","2 ст. л. томатного пюре","3 ст. л. яблочного уксуса","2 ст. л. мёда","6 булочек для бургеров, разрезанных","200 г салата коулслоу, по желанию"}	{"Смешайте сахар, паприку, зиру, чеснок, соль и перец в небольшой миске и натрите свинину со всех сторон. Вымойте руки и доску после работы с сырой свининой.","Распределите лук по дну медленноварки и положите сверху свинину.","Взбейте пассату, томатное пюре, яблочный уксус и мёд и полейте свинину.","Накройте и готовьте на низком режиме 8 часов (или на высоком 5 часов), пока свинина не станет очень мягкой и не будет легко распадаться. Температура будет намного выше 63 °C.","Переложите свинину на доску и разберите двумя вилками, удалив жир. Снимите жир с соуса и верните разобранное мясо в медленноварку.","Выложите в булочки, по желанию с коулслоу. Остудите остатки в течение 2 часов и заморозьте порциями с небольшим количеством соуса на срок до 3 месяцев; разогревайте до очень горячего состояния."}	ai	2026-11-20 15:44:58.082319+00
tablewise:catalog:v1:slow-cooker-pulled-pork	he	חזיר מפורק בסיר בישול איטי	{"1.5 ק\\"ג כתף חזיר ללא עצם, ללא עור ושומן עודף","2 כפות סוכר חום רך","2 כפיות פפריקה מעושנת","1 כפית כמון טחון","1 כפית גרגירי שום","1.5 כפיות מלח","0.5 כפית פלפל שחור","1 בצל, פרוס","200 גרם פסאטה","2 כפות רסק עגבניות","3 כפות חומץ תפוחים","2 כפות דבש","6 לחמניות המבורגר, פרוסות","200 גרם קולסלו, לא חובה"}	{"ערבבו בקערה קטנה את הסוכר, הפפריקה, הכמון, גרגירי השום, המלח והפלפל ושפשפו על כל הבשר. שטפו ידיים וקרש אחרי טיפול בבשר חזיר נא.","פזרו את הבצל על תחתית הסיר האיטי והניחו את הבשר מעליו.","טרפו יחד את הפסאטה, רסק העגבניות, חומץ התפוחים והדבש ויצקו על הבשר.","כסו ובשלו בעוצמה נמוכה 8 שעות (או בעוצמה גבוהה 5 שעות) עד שהבשר רך מאוד ומתפרק בקלות. הטמפרטורה תהיה הרבה מעל 63 מעלות.","הרימו את הבשר לקרש ופרקו אותו בשני מזלגות, תוך השלכת השומן. הסירו את השומן מהרוטב והחזירו את הבשר המפורק לסיר.","מלאו את הלחמניות, עם קולסלו אם רוצים. צננו שאריות בתוך שעתיים והקפיאו במנות עם מעט רוטב עד 3 חודשים; חממו עד שהן חמות מאוד."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:spaghetti-meatballs	ru	Спагетти с фрикадельками из говядины и колбасок	{"8 колбасок, без оболочки","500 г говяжьего фарша","4 зубчика чеснока, раздавленных","1 небольшой пучок петрушки, нарубленной","3 ст. л. сухих панировочных сухарей","1 яйцо, взбитое","Пшеничная мука для обваливания","4 ст. л. подсолнечного масла","2 банки резаных томатов","1 щепотка сахара","500 г спагетти","Тёртый пармезан для подачи","Соль и чёрный перец по вкусу"}	{"Смешайте в большой миске колбасный фарш, говядину, половину чеснока и петрушки, сухари и яйцо. Приправьте и перемешайте.","На присыпанной мукой разделочной доске скатайте шарики размером с десертную ложку. Обжарьте партиями в большой сковороде с 3 столовыми ложками масла и отложите.","Слейте лишний жир и очистите сковороду. Разогрейте оставшееся масло, быстро обжарьте оставшийся чеснок, затем готовьте томаты 5 минут; приправьте сахаром, солью и перцем.","Верните фрикадельки, накройте и тушите на слабом огне около 30 минут, переворачивая в соусе и при необходимости добавляя немного воды.","За последние 15 минут отварите спагетти в кастрюле. Вмешайте петрушку в соус и подавайте поверх откинутой пасты с пармезаном."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:spaghetti-meatballs	he	ספגטי עם קציצות בקר ונקניקיות	{"8 נקניקיות, ללא קליפה","500 גרם בשר בקר טחון","4 שיני שום, כתושות","1 צרור קטן פטרוזיליה, קצוצה","3 כפות פירורי לחם יבשים","1 ביצה, טרופה","קמח לבן לגלגול","4 כפות שמן חמניות","2 פחיות עגבניות קצוצות","1 קורט סוכר","500 גרם ספגטי","פרמזן מגורר להגשה","מלח ופלפל שחור לפי הטעם"}	{"ערבבו בקערה גדולה את בשר הנקניקיות, הבקר, חצי מהשום והפטרוזיליה, פירורי הלחם והביצה. תבלו וערבבו.","על קרש חיתוך מקומח גלגלו כדורים בגודל כף קינוח. השחימו במנות במחבת גדולה עם 3 כפות שמן והניחו בצד.","השליכו את השומן העודף ונקו את המחבת. חממו את שארית השמן, טגנו קצרות את שארית השום, ואז בשלו את העגבניות 5 דקות; תבלו בסוכר, מלח ופלפל.","החזירו את הקציצות, כסו ובשלו על אש קטנה כ-30 דקות, תוך הפיכה ברוטב והוספת מעט מים לפי הצורך.","בשלו את הספגטי בסיר במהלך 15 הדקות האחרונות. ערבבו את הפטרוזיליה לתוך הרוטב והגישו מעל הפסטה המסוננת עם פרמזן."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:spanish-omelette	ru	Испанский омлет с картофелем и перцем	{"500 г картофеля с плотной мякотью","Сливочное масло: кусочек и ещё немного для сковороды","2 небольшие луковицы, тонко нарезанные","1 красный перец, нарезанный","8–9 яиц","25 г зелёного лука-резанца","Соль и чёрный перец по вкусу"}	{"Нарежьте картофель ломтиками толщиной около 0,5 см. Томите лук в масле на сковороде диаметром около 24 см 10–15 минут, затем добавьте перец на 5 минут.","Тем временем размягчите картофель в кастрюле с кипящей водой 8–10 минут, затем слейте воду.","Взбейте яйца в кувшине, добавьте соль, перец и нарезанный лук-резанец. Разогрейте гриль и добавьте на сковороду ещё немного масла и картофель.","Влейте яйца и готовьте на слабом огне около 15 минут, пока омлет почти не схватится и не подрумянится снизу.","Доведите под грилем 1–2 минуты. Берегитесь горячей ручки; используйте подходящую сковороду. В данных сохранено указанное издателем время готовки — 30 минут."}	ai	2026-11-20 15:44:58.082319+00
tablewise:real:v1:spanish-omelette	he	חביתה ספרדית עם תפוחי אדמה ופלפל	{"500 גרם תפוחי אדמה מוצקים","חמאה: קוביה ועוד מעט למחבת","2 בצלים קטנים, פרוסים דק","1 פלפל אדום, קצוץ","8–9 ביצים","25 גרם עירית","מלח ופלפל שחור לפי הטעם"}	{"פרסו את תפוחי האדמה לפרוסות בעובי של כ-0.5 ס\\"מ. בשלו בעדינות את הבצלים בחמאה במחבת בקוטר של כ-24 ס\\"מ 10–15 דקות, ואז הוסיפו את הפלפל ל-5 דקות.","בינתיים רככו את תפוחי האדמה בסיר עם מים רותחים 8–10 דקות, ואז סננו.","טרפו את הביצים בכד, הוסיפו תיבול ועירית קצוצה. חממו את הגריל והוסיפו למחבת עוד מעט חמאה ואת תפוחי האדמה.","יצקו את הביצים ובשלו בעדינות כ-15 דקות עד שהחביתה כמעט מוצקה ומשחימה מלמטה.","סיימו מתחת לגריל 1–2 דקות. היזהרו מהידית החמה; השתמשו במחבת מתאימה. הנתונים שומרים את זמן הבישול שציין המוציא לאור — 30 דקות."}	ai	2026-11-20 15:44:58.082319+00
tablewise:catalog:v1:tofu-vegetable-stir-fry	ru	Тофу с овощами в воке	{"300 г риса жасмин","450 г очень плотного тофу, слить и обсушить","3 ч. л. кукурузного крахмала, разделить","3 ст. л. тамари (соевый соус без глютена)","1 ст. л. кленового сиропа","1 ст. л. рисового уксуса","1 ч. л. поджаренного кунжутного масла","4 ст. л. воды","3 ст. л. растительного масла, разделить","250 г соцветий брокколи","1 красный перец, нарезанный","1 морковь, нарезанная тонкими брусочками","150 г сахарного горошка","2 зубчика чеснока, мелко нарубленных","15 г свежего имбиря, натёртого","3 стебля зелёного лука, нарезанных","1 ст. л. кунжута, по желанию"}	{"Отварите рис в кастрюле по инструкции на упаковке и держите в тепле.","Нарежьте тофу кубиками по 2 см и перемешайте в миске с 2 ч. л. крахмала. В маленькой миске смешайте тамари, кленовый сироп, уксус, кунжутное масло, воду и оставшийся крахмал для соуса.","Разогрейте 2 ст. л. растительного масла в воке или большой сковороде на огне выше среднего. Жарьте тофу 8–10 минут, переворачивая, до хрустящей золотистой корочки со всех сторон. Переложите на тарелку.","Добавьте оставшееся масло и обжаривайте брокколи, перец и морковь 3 минуты. Добавьте сахарный горошек, чеснок и имбирь и жарьте ещё 2 минуты, пока овощи не станут мягкими, но ещё хрустящими.","Перемешайте соус, влейте в вок и прогрейте 1 минуту до блеска. Верните тофу, перемешайте, затем посыпьте зелёным луком и кунжутом. Подавайте с рисом."}	ai	2026-11-20 15:44:58.082319+00
tablewise:catalog:v1:tofu-vegetable-stir-fry	he	מוקפץ טופו וירקות	{"300 גרם אורז יסמין","450 גרם טופו קשה במיוחד, מסונן ומיובש","3 כפיות קורנפלור, מחולקות","3 כפות טמרי (רוטב סויה ללא גלוטן)","1 כף סירופ מייפל","1 כף חומץ אורז","1 כפית שמן שומשום קלוי","4 כפות מים","3 כפות שמן צמחי, מחולקות","250 גרם פרחי ברוקולי","1 פלפל אדום, פרוס","1 גזר, חתוך למקלות דקים","150 גרם אפונת שלג","2 שיני שום, קצוצות דק","15 גרם ג'ינג'ר טרי, מגורר","3 בצלים ירוקים, פרוסים","1 כף שומשום, לא חובה"}	{"בשלו את האורז בסיר לפי ההוראות שעל האריזה ושמרו חם.","חתכו את הטופו לקוביות של 2 ס\\"מ וערבבו בקערה עם 2 כפיות מהקורנפלור. בקערה קטנה ערבבו את הטמרי, סירופ המייפל, החומץ, שמן השומשום, המים ושארית הקורנפלור להכנת הרוטב.","חממו 2 כפות מהשמן הצמחי בווק או במחבת גדולה על אש בינונית-גבוהה. טגנו את הטופו 8–10 דקות תוך הפיכה, עד שהוא פריך וזהוב מכל הצדדים. העבירו לצלחת.","הוסיפו את שארית השמן והקפיצו את הברוקולי, הפלפל והגזר 3 דקות. הוסיפו את אפונת השלג, השום והג'ינג'ר והקפיצו עוד 2 דקות, עד שהירקות רכים אך עדיין פריכים.","ערבבו את הרוטב, יצקו לווק ובעבעו דקה אחת עד שהוא מבריק. החזירו את הטופו, ערבבו לציפוי ופזרו בצל ירוק ושומשום. הגישו עם האורז."}	ai	2026-11-20 15:44:58.082319+00
tablewise:catalog:v1:flatbread-pizzas	ru	Пиццы на лепёшках с томатами и моцареллой	{"300 г самоподнимающейся муки и ещё немного для подпыла","300 г натурального йогурта","0,5 ч. л. соли","1 ст. л. оливкового масла","150 г пассаты","1 зубчик чеснока, раздавленный","1 ч. л. сушёного орегано","250 г моцареллы, обсушить и порвать","150 г томатов черри, разрезанных пополам","10 г свежих листьев базилика, по желанию"}	{"Разогрейте духовку до 240 °C (220 °C с конвекцией) и поставьте в неё нагреваться два больших противня.","Смешайте муку, йогурт и соль в миске до мягкого теста. Коротко вымесите на присыпанной мукой поверхности до гладкости, затем разделите на четыре части и раскатайте каждую в тонкий овал.","Смешайте пассату с чесноком и орегано. Смажьте горячие противни маслом и выложите на них лепёшки.","Распределите томатный соус по основам, затем выложите моцареллу и томаты черри.","Выпекайте 10–12 минут, пока основы не станут хрустящими снизу, а сыр не начнёт пузыриться. По желанию посыпьте базиликом и нарежьте на куски."}	ai	2026-11-20 15:44:58.082319+00
tablewise:catalog:v1:flatbread-pizzas	he	פיצות על לחם שטוח עם עגבניות ומוצרלה	{"300 גרם קמח תופח ועוד מעט לקימוח","300 גרם יוגורט טבעי","0.5 כפית מלח","1 כף שמן זית","150 גרם פסאטה","1 שן שום, כתושה","1 כפית אורגנו יבש","250 גרם מוצרלה, מסוננת וקרועה","150 גרם עגבניות שרי, חצויות","10 גרם עלי בזיליקום טרי, לא חובה"}	{"חממו את התנור ל-240 מעלות (220 מעלות בטורבו) והכניסו שתי תבניות אפייה גדולות להתחמם.","ערבבו בקערה את הקמח, היוגורט והמלח לבצק רך. לושו קצרות על משטח מקומח עד שהבצק חלק, חלקו לארבעה ורדדו כל חלק לאליפסה דקה.","ערבבו את הפסאטה עם השום והאורגנו. הברישו את התבניות החמות בשמן והניחו עליהן את הלחמים השטוחים.","מרחו את רוטב העגבניות על הבסיסים, ואז הוסיפו את המוצרלה ועגבניות השרי.","אפו 10–12 דקות עד שהבסיסים פריכים מלמטה והגבינה מבעבעת. פזרו בזיליקום אם רוצים וחתכו לפרוסות."}	ai	2026-11-20 15:44:58.082319+00
tablewise:catalog:v1:rice-noodle-salad	ru	Салат с рисовой лапшой по-вьетнамски	{"400 г плотного тофу, слить и обсушить","1 ст. л. кукурузного крахмала","2 ст. л. растительного масла","200 г рисовой лапши","2 моркови, нарезанные соломкой","1 огурец, нарезанный соломкой","1 кочанчик салата литл джем, нашинкованный","15 г свежей мяты, только листья","15 г свежей кинзы, только листья","50 г жареного арахиса, крупно нарубленного","2 лайма, выжать сок","3 ст. л. тамари (соевый соус без глютена)","1,5 ст. л. светлого коричневого сахара","3 ст. л. воды","1 красный перец чили, мелко нарубленный","1 зубчик чеснока, раздавленный"}	{"Приготовьте заправку: смешайте в кувшине сок лайма, тамари, сахар, воду, чили и чеснок, пока сахар не растворится.","Нарежьте тофу кубиками по 2 см и перемешайте с крахмалом. Жарьте в масле в большой сковороде на огне выше среднего 8–10 минут, переворачивая, до золотистой хрустящей корочки со всех сторон. Полейте 2 ст. л. заправки и перемешайте.","Тем временем отварите рисовую лапшу в кастрюле с кипящей водой по инструкции на упаковке, обычно 3–4 минуты. Откиньте, промойте холодной водой и хорошо обсушите.","Разложите салат и лапшу по мискам и выложите сверху морковь, огурец, тофу, мяту и кинзу.","Полейте оставшейся заправкой и посыпьте арахисом непосредственно перед подачей."}	ai	2026-11-20 15:44:58.082319+00
tablewise:catalog:v1:rice-noodle-salad	he	סלט אטריות אורז בסגנון וייטנאמי	{"400 גרם טופו קשה, מסונן ומיובש","1 כף קורנפלור","2 כפות שמן צמחי","200 גרם אטריות אורז","2 גזרים, חתוכים לגפרורים","1 מלפפון, חתוך לגפרורים","1 חסה ליטל ג'ם, פרוסה דק","15 גרם נענע טרייה, עלים בלבד","15 גרם כוסברה טרייה, עלים בלבד","50 גרם בוטנים קלויים, קצוצים גס","2 ליים, סחוטים","3 כפות טמרי (רוטב סויה ללא גלוטן)","1.5 כפות סוכר חום בהיר","3 כפות מים","1 צ'ילי אדום, קצוץ דק","1 שן שום, כתושה"}	{"הכינו את הרוטב: ערבבו בכד את מיץ הליים, הטמרי, הסוכר, המים, הצ'ילי והשום עד שהסוכר נמס.","חתכו את הטופו לקוביות של 2 ס\\"מ וערבבו עם הקורנפלור. טגנו בשמן במחבת גדולה על אש בינונית-גבוהה 8–10 דקות תוך הפיכה, עד שהוא זהוב ופריך מכל הצדדים. יצקו מעליו 2 כפות מהרוטב וערבבו.","בינתיים בשלו את אטריות האורז בסיר עם מים רותחים לפי ההוראות שעל האריזה, בדרך כלל 3–4 דקות. סננו, שטפו במים קרים וסננו היטב.","חלקו את החסה והאטריות לקערות והוסיפו מעל את הגזר, המלפפון, הטופו, הנענע והכוסברה.","יצקו את שארית הרוטב ופזרו את הבוטנים ממש לפני ההגשה."}	ai	2026-11-20 15:44:58.082319+00
\.


--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recipes (id, title, ingredients, steps, step_analysis, image, source_url, cook_time, prep_time, servings, credit_kind, credit_name, tags, created_at, updated_at, ingredient_parts, step_ingredients, language) FROM stdin;
tablewise:real:v1:chicken-curry	Easy chicken curry	{"2 tbsp sunflower oil","1 onion, thinly sliced","2 garlic cloves, crushed","1 thumb-sized piece ginger, grated","6 boneless skinless chicken thighs","3 tbsp medium curry paste","400 g canned chopped tomatoes","100 g Greek yogurt","1 small bunch coriander, chopped","50 g ground almonds","Salt, to taste","Naan bread or cooked basmati rice, optional, to serve"}	{"In a large frying pan, soften the onion in the oil with a pinch of salt over medium heat for 8–10 minutes.","Stir in the garlic and ginger for 1 minute. Cut the chicken into approximately 3 cm pieces and fry in the pan for 5 minutes.","Add the curry paste, tomatoes and 250 ml water. Bring to a boil, then simmer uncovered for 25–30 minutes, until the sauce thickens and the chicken is cooked through.","Mix in the yogurt, coriander and ground almonds. Adjust seasoning and serve; naan or separately cooked rice is optional."}	\N	\N	https://www.bbcgoodfood.com/recipes/easy-chicken-curry	45	5	4	\N	\N	{Dinner,Chicken,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074	\N	\N	en
tablewise:real:v1:salmon-egg-fried-rice	Salmon egg-fried rice	{"1 thumb-sized piece ginger, grated","1–2 garlic cloves, grated","2 tbsp low-salt soy sauce","0.5 tbsp rice wine vinegar","2 tbsp vegetable oil","1 large carrot, chopped","175 g baby corn and mangetout, chopped","2 skinless smoked salmon fillets","250 g pouch cooked brown basmati rice","2 eggs","Hot sauce, optional, to serve"}	{"Combine the ginger, garlic, soy sauce and vinegar in a bowl.","Heat a large wok with 1 tablespoon oil. Add the carrot, mixed vegetables and salmon; cook the fish for approximately 2 minutes per side.","Stir in the ready-cooked rice, separating the fish into flakes. Push the mixture aside, add the remaining oil and scramble the eggs in the clear space.","Fold everything together with the soy mixture and heat thoroughly for a few minutes. Offer hot sauce separately."}	\N	\N	https://www.bbcgoodfood.com/recipes/salmon-egg-fried-rice	10	10	2–3	\N	\N	{Dinner,Fish,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074	\N	\N	en
tablewise:real:v1:lentil-leek-soup	Red lentil, carrot and leek soup	{"2 litres vegetable stock","150 g red lentils","6 carrots, finely chopped","2 medium leeks, sliced (about 300 g)","1 small handful parsley, chopped","Salt and black pepper, to taste"}	{"Heat the vegetable stock in a large saucepan and stir in the red lentils.","Bring to a boil and let the lentils start softening for a few minutes.","Add carrots and leeks, season to taste, cover and simmer gently for 45–60 minutes until the vegetables are tender and the lentils break down.","Top each portion with parsley. The source also allows ham stock; this version selects its vegetarian stock option."}	\N	\N	https://www.bbcgoodfood.com/recipes/lentil-soup	60	10	4	\N	\N	{Dinner,Vegetarian,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074	\N	\N	en
tablewise:real:v1:baked-salmon	Simple baked salmon	{"4 skinless salmon fillets","1 tbsp olive oil","Salt and black pepper, to taste","Chopped herbs, optional, to serve","Lemon slices, optional, to serve","Steamed long-stem broccoli, optional, to serve"}	{"Preheat the oven to 180°C, or 160°C fan. Brush the salmon with olive oil and season.","Arrange the fillets in an ovenproof dish. Cover for a softer finish, or leave uncovered for a lightly roasted surface.","Bake for 10–15 minutes, adjusting for thickness, until the fish is opaque and flakes readily.","Serve with the optional herbs, lemon and separately steamed broccoli. Those accompaniments are not a fixed quantity in the source."}	\N	\N	https://www.bbcgoodfood.com/recipes/baked-salmon	15	5	4	\N	\N	{Dinner,Fish,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074	\N	\N	en
tablewise:real:v1:coconut-chickpea-curry	Coconut chickpea and kale curry	{"1.5 tbsp curry powder","1 tsp cumin","1 yellow onion, diced","2 garlic cloves, minced","1 tsp fresh ginger, grated","2 tbsp olive oil","2 cans chickpeas (15 oz each), drained","1 can tomato sauce (8 oz)","1 can full-fat coconut milk (13.5 oz)","4 oz kale, chopped","Salt, to taste","Cooked rice or bread, optional, to serve"}	{"Dice the onion, mince the garlic, grate the ginger and chop the kale.","Toast the curry powder and cumin in a dry deep skillet over medium-low heat for approximately 1 minute.","Add the olive oil, onion, garlic and ginger; soften for approximately 5 minutes. Stir in drained chickpeas, tomato sauce and coconut milk.","Bring to a simmer, reduce the heat and cook for 15 minutes, stirring occasionally.","Fold in the kale and cook approximately 5 minutes more, until tender. Salt to taste and offer separately prepared rice or bread if desired."}	\N	\N	https://www.budgetbytes.com/coconut-curry-chickpeas/	25	10	4	\N	\N	{Dinner,Vegan,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074	\N	\N	en
tablewise:real:v1:sundried-tomato-pasta	One-pot creamy sun-dried tomato pasta	{"0.5 cup sun-dried tomatoes","2 tbsp butter","2 garlic cloves, minced","8 oz fettuccine","0.5 tsp dried basil","Black pepper, to taste","2 cups chicken broth","2 oz cream cheese","1 cup whole milk","0.25 cup grated Parmesan"}	{"Chop the sun-dried tomatoes. Melt the butter in a deep skillet and gently fry the garlic for approximately 1 minute.","Add pasta, tomatoes, basil, pepper and chicken broth. Break the pasta if necessary so it sits in the liquid.","Cover, bring to a boil, then reduce to a gentle simmer. Stir every few minutes and replace the lid.","Cook for 7–10 minutes until the pasta is tender and most broth is absorbed. Over low heat, melt in the cream cheese, then stir in milk and Parmesan to finish the sauce."}	\N	\N	https://www.budgetbytes.com/one-pot-creamy-sun-dried-tomato-pasta/	20	10	4	\N	\N	{Dinner,Pasta,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074	\N	\N	en
tablewise:real:v1:spanish-omelette	Spanish potato and pepper omelette	{"500 g waxy potatoes","Butter, a knob plus a little extra for the pan","2 small onions, finely sliced","1 red pepper, chopped","8–9 eggs","25 g chives","Salt and black pepper, to taste"}	{"Slice the potatoes approximately 0.5 cm thick. Gently cook onions in butter in a roughly 24 cm frying pan for 10–15 minutes, then add pepper for 5 minutes.","Meanwhile, soften the potatoes in a saucepan of boiling water for 8–10 minutes, then drain.","Beat eggs in a jug, add seasoning and snipped chives. Heat the grill and add a little more butter and the potatoes to the frying pan.","Pour in the eggs and cook gently for approximately 15 minutes until almost set and browned beneath.","Finish under the grill for 1–2 minutes. Protect yourself from the hot handle; use a suitable pan. The metadata retains the publisher's stated 30-minute cooking time."}	\N	\N	https://www.bbcgoodfood.com/recipes/spanish-omelette	30	10	3–4	\N	\N	{Dinner,Vegetarian,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074	\N	\N	en
tablewise:real:v1:sichuan-beef-stir-fry	Beef and Sichuan pepper stir-fry	{"2 tbsp rapeseed oil","300 g steak, thinly sliced","1 tbsp cornflour","2 mixed peppers, sliced","200 g baby corn, halved","2 small red onions, sliced","0.5 tsp chilli flakes","1 tsp Sichuan peppercorns, ground","2 tbsp low-salt dark soy sauce","1 tbsp chilli oil, optional","300 g cooked brown basmati rice"}	{"Grind the Sichuan peppercorns using a pestle and mortar.","Heat 1 tablespoon rapeseed oil in a large wok. Add steak and cornflour, turn to coat, and fry for 2–3 minutes until browned; transfer to a plate.","Add remaining oil, peppers, baby corn and onion. Stir-fry for 3–4 minutes, then return beef and its juices with chilli flakes and Sichuan pepper.","Cook for 1 minute, add soy sauce and 50 ml water, and stir until the sauce coats everything. Serve with the ready-cooked rice and optional chilli oil."}	\N	\N	https://www.bbcgoodfood.com/recipes/beef-sichuan-pepper-stir-fry	10	10	4	\N	\N	{Dinner,Beef,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074	\N	\N	en
tablewise:real:v1:spaghetti-meatballs	Spaghetti with beef and sausage meatballs	{"8 sausages, skins removed","500 g minced beef","4 garlic cloves, crushed","1 small bunch parsley, chopped","3 tbsp dried breadcrumbs","1 egg, beaten","Plain flour, for rolling","4 tbsp sunflower oil","2 cans chopped tomatoes","1 pinch sugar","500 g spaghetti","Grated Parmesan, to serve","Salt and black pepper, to taste"}	{"Combine sausage meat, beef, half the garlic and parsley, breadcrumbs and egg in a large bowl. Season and mix.","On a floured chopping board, roll dessertspoon-sized portions into balls. Brown in batches in a large frying pan with 3 tablespoons oil, then set aside.","Discard excess fat and clean the pan. Warm the remaining oil, briefly fry remaining garlic, then cook the tomatoes for 5 minutes; season with sugar, salt and pepper.","Return meatballs, cover and simmer gently for approximately 30 minutes, turning in the sauce and adding a little water if needed.","Cook spaghetti in a saucepan during the final 15 minutes. Stir parsley into the sauce and serve over drained pasta with Parmesan."}	\N	\N	https://www.bbcgoodfood.com/recipes/meatballs-spaghetti	45	30	6	\N	\N	{Dinner,Beef,Pasta,Source-verified}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074	\N	\N	en
tablewise:synthetic:v1:002	Sardine linguine	{"250 g dry pasta","1 tin sardines or mackerel, drained (or 300 g cleaned mussels)","2 garlic cloves, minced","200 g cherry tomatoes","2 tbsp olive oil","1 tbsp lemon juice","Chopped parsley, to taste"}	{"Cook pasta in salted water and reserve a little cooking liquid.","Warm oil and garlic, then soften tomatoes in a pan.","Add fish and warm through, or cook mussels until opened; discard unopened mussels.","Toss with pasta, lemon juice and parsley; loosen with pasta water."}	\N	\N	https://www.jamieoliver.com/recipes/pasta/	15	10	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074	\N	\N	en
tablewise:synthetic:v1:006	Simple arrabbiata	{"250 g dry pasta","2 tbsp olive oil","2 garlic cloves, minced","300 g tomatoes, chopped","1 small courgette or bell pepper, diced","1 tsp dried herbs","Salt and pepper, to taste"}	{"Cook pasta according to the package directions; drain.","Heat oil, sauté garlic and vegetables until softened.","Add tomatoes and herbs and simmer for 10 minutes.","Combine sauce with pasta; season and serve."}	\N	\N	https://www.jamieoliver.com/recipes/pasta/	20	10	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074	\N	\N	en
tablewise:synthetic:v1:021	Feta & tomato pasta	{"250 g dry pasta","2 tbsp olive oil","2 garlic cloves, minced","300 g tomatoes, chopped","1 small courgette or bell pepper, diced","1 tsp dried herbs","Salt and pepper, to taste"}	{"Cook pasta according to the package directions; drain.","Heat oil, sauté garlic and vegetables until softened.","Add tomatoes and herbs and simmer for 10 minutes.","Combine sauce with pasta; season and serve."}	\N	\N	https://www.jamieoliver.com/recipes/pasta/	25	10	4	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074	\N	\N	en
tablewise:synthetic:v1:050	Michigan French Toast Sandwich	{"200 g all-purpose flour","80 g sugar","2 eggs","100 ml milk","80 ml neutral oil","1 tsp baking powder","1 tsp vanilla extract"}	{"Preheat oven to 180°C (356°F) and prepare a baking pan or muffin tin.","Whisk eggs, milk, oil, sugar and vanilla.","Fold in flour and baking powder until just combined.","Bake until golden and a skewer comes out clean; cool before serving."}	\N	\N	https://www.gordonramsay.com/gr/recipes/	10	10	2	\N	\N	{"Synthetic test data","Unverified collection link"}	2026-11-11 16:22:53.549074	2026-11-11 16:22:53.549074	\N	\N	en
tablewise:catalog:v1:aubergine-parmigiana	Aubergine parmigiana	{"3 large aubergines, sliced lengthways","5 tbsp olive oil, divided","1 onion, finely chopped","3 cloves garlic, crushed","800 g canned chopped tomatoes","1 tbsp tomato purée","1 tsp sugar","0.75 tsp salt","20 g fresh basil, leaves torn","250 g mozzarella, drained and torn","60 g vegetarian hard cheese, finely grated"}	{"Heat the oven to 220°C (fan 200°C). Cut the aubergines into slices about 1 cm thick, brush both sides with 4 tbsp of the oil, spread over two baking trays and roast for 20–25 minutes, turning once, until soft and golden.","Meanwhile, heat the remaining oil in a saucepan over medium heat. Cook the onion for 6–8 minutes until soft, then add the garlic for 1 minute.","Add the tomatoes, tomato purée, sugar and salt and simmer for 15 minutes until thick. Stir in most of the basil.","Turn the oven down to 190°C (fan 170°C). In a baking dish, layer a little sauce, then aubergine, mozzarella and a sprinkle of hard cheese. Repeat the layers, finishing with sauce and the remaining hard cheese.","Bake for 30–35 minutes, until bubbling and golden on top. Rest for 10 minutes, then scatter with the remaining basil and serve."}	\N	\N	\N	60	25	4	\N	\N	{Dinner,Italian,Vegetarian,Gluten-free}	2026-11-12 05:01:51.504085	2026-11-12 05:01:51.504085	\N	\N	en
tablewise:catalog:v1:flatbread-pizzas	Tomato and mozzarella flatbread pizzas	{"300 g self-raising flour, plus extra for dusting","300 g natural yogurt","0.5 tsp salt","1 tbsp olive oil","150 g passata","1 clove garlic, crushed","1 tsp dried oregano","250 g mozzarella, drained and torn","150 g cherry tomatoes, halved","10 g fresh basil leaves, optional"}	{"Heat the oven to 240°C (fan 220°C) and put two large baking trays in to heat.","Mix the flour, yogurt and salt in a mixing bowl to a soft dough. Knead briefly on a floured surface until smooth, then divide into four and roll each into a thin oval.","Stir the passata with the garlic and oregano. Brush the hot baking trays with the oil and lay the flatbreads on them.","Spread the tomato sauce over the bases, then top with the mozzarella and cherry tomatoes.","Bake for 10–12 minutes until the bases are crisp underneath and the cheese is bubbling. Scatter with basil if using and cut into slices."}	\N	\N	\N	12	20	4	\N	\N	{Lunch,Italian,Vegetarian,"Kid friendly",Budget,Baking}	2026-11-12 05:01:51.504085	2026-11-12 05:01:51.504085	\N	\N	en
tablewise:catalog:v1:fish-pie	Fish pie	{"1 kg floury potatoes, peeled and cut into chunks","90 g butter, divided","600 ml whole milk, divided","40 g plain flour","1 bay leaf","450 g fish pie mix, skinless cod, salmon and smoked haddock","150 g raw peeled prawns","150 g frozen peas","2 tbsp fresh parsley, chopped","50 g mature Cheddar, grated","0.5 tsp salt","0.25 tsp black pepper"}	{"Heat the oven to 200°C (fan 180°C). Boil the potatoes in a large pot of salted water for 15–18 minutes until tender, then drain and mash with 50 g of the butter and 100 ml of the milk. Season with half the salt.","Meanwhile, melt the remaining 40 g butter in a saucepan over medium heat, stir in the flour and cook for 1 minute. Gradually whisk in the remaining 500 ml milk, add the bay leaf and simmer, stirring, for 3–4 minutes until smooth and thick. Remove the bay leaf and season with the rest of the salt and the pepper.","Spread the raw fish, prawns and peas over the base of a baking dish of about 2 litres. Stir the parsley into the sauce and pour it over evenly.","Spoon the mash over the top, starting at the edges to seal, then rough it up with a fork and scatter over the cheese.","Set the dish on a baking tray and bake for 30–35 minutes, until golden and bubbling at the edges, the fish is opaque and flakes easily and the prawns are pink throughout. Rest for 5 minutes before serving.","To batch cook, cool the assembled unbaked pie, cover and refrigerate for up to 24 hours, then bake for 45–50 minutes until piping hot in the centre."}	\N	\N	\N	50	25	4	\N	\N	{Dinner,British,Fish,Seafood,"Kid friendly","Batch cooking",Potatoes}	2026-11-12 05:01:51.504085	2026-11-12 05:01:51.504085	\N	\N	en
tablewise:catalog:v1:pork-schnitzel	Pork schnitzel	{"750 g new potatoes, halved if large","15 g butter","1 tbsp fresh parsley, chopped","4 boneless pork loin steaks, fat trimmed","50 g plain flour","0.5 tsp salt","0.25 tsp black pepper","2 eggs","100 g panko breadcrumbs","6 tbsp vegetable oil","1 lemon, cut into wedges"}	{"Boil the potatoes in a large pot of salted water for 15–18 minutes until tender. Drain and toss with the butter and parsley; keep warm.","Meanwhile, lay each pork steak between two sheets of baking paper and bash with a rolling pin until about 5 mm thick.","Set out three shallow dishes: the flour mixed with the salt and pepper, the eggs beaten, and the breadcrumbs. Coat each steak in flour, then egg, then breadcrumbs, pressing to stick. Wash your hands and board after handling the raw pork.","Heat half the oil in a large frying pan over medium-high heat. Fry two schnitzels for 2–3 minutes per side, until deep golden and cooked through (at least 63°C in the centre). Drain on kitchen paper and repeat with the remaining oil and pork.","Rest the schnitzels for 3 minutes, then serve with the potatoes and lemon wedges for squeezing."}	\N	\N	\N	25	20	4	\N	\N	{Dinner,International,Pork,"Kid friendly",Potatoes}	2026-11-12 05:01:51.504085	2026-11-12 05:01:51.504085	\N	\N	en
tablewise:catalog:v1:slow-cooker-pulled-pork	Slow cooker pulled pork	{"1.5 kg boneless pork shoulder, rind and excess fat removed","2 tbsp soft brown sugar","2 tsp smoked paprika","1 tsp ground cumin","1 tsp garlic granules","1.5 tsp salt","0.5 tsp black pepper","1 onion, sliced","200 g passata","2 tbsp tomato purée","3 tbsp cider vinegar","2 tbsp honey","6 burger buns, split","200 g coleslaw, optional"}	{"Mix the sugar, paprika, cumin, garlic granules, salt and pepper in a small mixing bowl and rub all over the pork. Wash your hands and board after handling the raw pork.","Scatter the onion over the base of the slow cooker and sit the pork on top.","Whisk the passata, tomato purée, cider vinegar and honey together and pour over the pork.","Cover and cook on low for 8 hours (or high for 5 hours) until the pork is very tender and falls apart easily. It will be well above 63°C.","Lift the pork onto a board and shred it with two forks, discarding any fat. Skim the fat from the sauce, then stir the shredded meat back into the slow cooker.","Pile into the buns with coleslaw if using. Cool leftovers within 2 hours and freeze in portions with some sauce for up to 3 months; reheat until piping hot."}	\N	\N	\N	480	15	6	\N	\N	{Dinner,American,Pork,"Kid friendly","Batch cooking"}	2026-11-12 05:01:51.504085	2026-11-12 05:01:51.504085	\N	\N	en
tablewise:catalog:v1:tofu-vegetable-stir-fry	Tofu and vegetable stir-fry	{"300 g jasmine rice","450 g extra-firm tofu, drained and patted dry","3 tsp cornflour, divided","3 tbsp tamari (gluten-free soy sauce)","1 tbsp maple syrup","1 tbsp rice vinegar","1 tsp toasted sesame oil","4 tbsp water","3 tbsp vegetable oil, divided","250 g broccoli florets","1 red pepper, sliced","1 carrot, cut into thin batons","150 g mangetout","2 cloves garlic, finely chopped","15 g fresh ginger, grated","3 spring onions, sliced","1 tbsp sesame seeds, optional"}	{"Cook the rice in a saucepan according to the packet instructions and keep warm.","Cut the tofu into 2 cm cubes and toss in a mixing bowl with 2 tsp of the cornflour. In a small bowl, mix the tamari, maple syrup, vinegar, sesame oil, water and remaining cornflour to make the sauce.","Heat 2 tbsp of the vegetable oil in a wok or large frying pan over medium-high heat. Fry the tofu for 8–10 minutes, turning, until crisp and golden on all sides. Lift onto a plate.","Add the remaining oil and stir-fry the broccoli, pepper and carrot for 3 minutes. Add the mangetout, garlic and ginger and stir-fry for 2 minutes more, until the vegetables are just tender but still crisp.","Stir the sauce, pour it into the wok and bubble for 1 minute until glossy. Return the tofu, toss to coat, then scatter with spring onions and sesame seeds. Serve with the rice."}	\N	\N	\N	20	20	4	\N	\N	{Dinner,Chinese,Vegetarian,Vegan,Gluten-free,Dairy-free,Rice}	2026-11-12 05:01:51.504085	2026-11-12 05:01:51.504085	\N	\N	en
tablewise:catalog:v1:rice-noodle-salad	Vietnamese-style rice noodle salad	{"400 g firm tofu, drained and patted dry","1 tbsp cornflour","2 tbsp vegetable oil","200 g rice noodles","2 carrots, cut into matchsticks","1 cucumber, cut into matchsticks","1 little gem lettuce, shredded","15 g fresh mint, leaves picked","15 g fresh coriander, leaves picked","50 g roasted peanuts, roughly chopped","2 limes, juiced","3 tbsp tamari (gluten-free soy sauce)","1.5 tbsp light brown sugar","3 tbsp water","1 red chilli, finely chopped","1 clove garlic, crushed"}	{"Make the dressing by stirring the lime juice, tamari, sugar, water, chilli and garlic together in a jug until the sugar dissolves.","Cut the tofu into 2 cm cubes and toss with the cornflour. Fry in the oil in a large frying pan over medium-high heat for 8–10 minutes, turning, until golden and crisp on all sides. Spoon over 2 tbsp of the dressing and toss.","Meanwhile, cook the rice noodles in a saucepan of boiling water according to the pack instructions, usually 3–4 minutes. Drain, rinse under cold water and drain well.","Divide the lettuce and noodles between bowls and top with the carrot, cucumber, tofu, mint and coriander.","Pour over the remaining dressing and scatter with the peanuts just before serving."}	\N	\N	\N	15	20	4	\N	\N	{Lunch,Vietnamese,Vegetarian,Vegan,Gluten-free,Dairy-free,Noodles}	2026-11-12 05:01:51.504085	2026-11-12 05:01:51.504085	\N	\N	en
\.


--
-- Name: account_sessions account_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_sessions
    ADD CONSTRAINT account_sessions_pkey PRIMARY KEY (token_hash);


--
-- Name: accounts accounts_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_email_unique UNIQUE (email);


--
-- Name: accounts accounts_owner_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_owner_id_unique UNIQUE (owner_id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: cooking_photos cooking_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cooking_photos
    ADD CONSTRAINT cooking_photos_pkey PRIMARY KEY (id);


--
-- Name: cooking_sessions cooking_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cooking_sessions
    ADD CONSTRAINT cooking_sessions_pkey PRIMARY KEY (id);


--
-- Name: grocery_extras grocery_extras_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grocery_extras
    ADD CONSTRAINT grocery_extras_pkey PRIMARY KEY (id);


--
-- Name: grocery_item_photos grocery_item_photos_owner_id_item_key_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grocery_item_photos
    ADD CONSTRAINT grocery_item_photos_owner_id_item_key_pk PRIMARY KEY (owner_id, item_key);


--
-- Name: grocery_notes grocery_notes_owner_id_item_key_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grocery_notes
    ADD CONSTRAINT grocery_notes_owner_id_item_key_pk PRIMARY KEY (owner_id, item_key);


--
-- Name: grocery_shopping_items grocery_shopping_items_owner_id_item_key_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grocery_shopping_items
    ADD CONSTRAINT grocery_shopping_items_owner_id_item_key_pk PRIMARY KEY (owner_id, item_key);


--
-- Name: home_tasks home_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_tasks
    ADD CONSTRAINT home_tasks_pkey PRIMARY KEY (id);


--
-- Name: household_products household_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.household_products
    ADD CONSTRAINT household_products_pkey PRIMARY KEY (id);


--
-- Name: household_settings household_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.household_settings
    ADD CONSTRAINT household_settings_pkey PRIMARY KEY (owner_id);


--
-- Name: household_tasks household_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.household_tasks
    ADD CONSTRAINT household_tasks_pkey PRIMARY KEY (id);


--
-- Name: pilot_events pilot_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pilot_events
    ADD CONSTRAINT pilot_events_pkey PRIMARY KEY (event_id);


--
-- Name: pilot_events pilot_events_semantic; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pilot_events
    ADD CONSTRAINT pilot_events_semantic UNIQUE (pilot_id, event_name, week_start, recipe_id);


--
-- Name: recipe_generations recipe_generations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_generations
    ADD CONSTRAINT recipe_generations_pkey PRIMARY KEY (id);


--
-- Name: recipe_marks recipe_marks_owner_id_recipe_id_kind_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_marks
    ADD CONSTRAINT recipe_marks_owner_id_recipe_id_kind_pk PRIMARY KEY (owner_id, recipe_id, kind);


--
-- Name: recipe_nutrition recipe_nutrition_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_nutrition
    ADD CONSTRAINT recipe_nutrition_pkey PRIMARY KEY (recipe_id);


--
-- Name: recipe_sources recipe_sources_owner_video_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_sources
    ADD CONSTRAINT recipe_sources_owner_video_unique UNIQUE (owner_id, provider, external_video_id);


--
-- Name: recipe_sources recipe_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_sources
    ADD CONSTRAINT recipe_sources_pkey PRIMARY KEY (id);


--
-- Name: recipe_sources recipe_sources_recipe_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_sources
    ADD CONSTRAINT recipe_sources_recipe_unique UNIQUE (recipe_id);


--
-- Name: recipe_translations recipe_translations_recipe_id_language_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_translations
    ADD CONSTRAINT recipe_translations_recipe_id_language_pk PRIMARY KEY (recipe_id, language);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: shared_grocery_items shared_grocery_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_grocery_items
    ADD CONSTRAINT shared_grocery_items_pkey PRIMARY KEY (id);


--
-- Name: shared_grocery_lists shared_grocery_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_grocery_lists
    ADD CONSTRAINT shared_grocery_lists_pkey PRIMARY KEY (id);


--
-- Name: shared_grocery_lists shared_grocery_lists_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_grocery_lists
    ADD CONSTRAINT shared_grocery_lists_token_unique UNIQUE (token);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: week_plans week_plans_owner_id_week_start_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.week_plans
    ADD CONSTRAINT week_plans_owner_id_week_start_pk PRIMARY KEY (owner_id, week_start);


--
-- Name: account_sessions_account; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX account_sessions_account ON public.account_sessions USING btree (account_id);


--
-- Name: cooking_photos_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cooking_photos_owner ON public.cooking_photos USING btree (owner_id);


--
-- Name: cooking_photos_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cooking_photos_session ON public.cooking_photos USING btree (session_id, created_at);


--
-- Name: cooking_sessions_owner_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cooking_sessions_owner_recipe ON public.cooking_sessions USING btree (owner_id, recipe_id, cooked_at);


--
-- Name: grocery_extras_owner_text; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX grocery_extras_owner_text ON public.grocery_extras USING btree (owner_id, text);


--
-- Name: home_tasks_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX home_tasks_owner ON public.home_tasks USING btree (owner_id);


--
-- Name: pilot_events_completion; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pilot_events_completion ON public.pilot_events USING btree (pilot_id, occurred_at, event_id) WHERE ((event_name)::text = 'plan_completed'::text);


--
-- Name: pilot_events_funnel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pilot_events_funnel ON public.pilot_events USING btree (event_name, week_start);


--
-- Name: recipe_generations_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX recipe_generations_owner ON public.recipe_generations USING btree (owner_id, created_at);


--
-- Name: recipe_generations_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX recipe_generations_recipe ON public.recipe_generations USING btree (recipe_id);


--
-- Name: shared_grocery_items_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shared_grocery_items_list ON public.shared_grocery_items USING btree (list_id);


--
-- Name: shared_grocery_lists_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shared_grocery_lists_owner ON public.shared_grocery_lists USING btree (owner_id, created_at);


--
-- Name: account_sessions account_sessions_account_id_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_sessions
    ADD CONSTRAINT account_sessions_account_id_accounts_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: cooking_photos cooking_photos_session_id_cooking_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cooking_photos
    ADD CONSTRAINT cooking_photos_session_id_cooking_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.cooking_sessions(id) ON DELETE CASCADE;


--
-- Name: cooking_sessions cooking_sessions_recipe_id_recipes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cooking_sessions
    ADD CONSTRAINT cooking_sessions_recipe_id_recipes_id_fk FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipe_generations recipe_generations_recipe_id_recipes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_generations
    ADD CONSTRAINT recipe_generations_recipe_id_recipes_id_fk FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE SET NULL;


--
-- Name: recipe_marks recipe_marks_recipe_id_recipes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_marks
    ADD CONSTRAINT recipe_marks_recipe_id_recipes_id_fk FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipe_nutrition recipe_nutrition_recipe_id_recipes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_nutrition
    ADD CONSTRAINT recipe_nutrition_recipe_id_recipes_id_fk FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipe_sources recipe_sources_recipe_id_recipes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_sources
    ADD CONSTRAINT recipe_sources_recipe_id_recipes_id_fk FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipe_translations recipe_translations_recipe_id_recipes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_translations
    ADD CONSTRAINT recipe_translations_recipe_id_recipes_id_fk FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: shared_grocery_items shared_grocery_items_list_id_shared_grocery_lists_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_grocery_items
    ADD CONSTRAINT shared_grocery_items_list_id_shared_grocery_lists_id_fk FOREIGN KEY (list_id) REFERENCES public.shared_grocery_lists(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict pV2boW4eAoCrTnmyKtkND0IYBhIhCSnPWrMrLvEUsmgrGPnsjvTLtGsj6OX6zYs

